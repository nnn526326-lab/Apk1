package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Panorama
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material.icons.filled.Timelapse
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VideoFeedStats
import com.example.ui.theme.AviationRed
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Mode kamera yang bisa dipilih. Tiap mode punya ikon, warna cincin, dan keterangan sendiri. */
enum class CameraMode(
    val label: String,
    val spec: String,
    val icon: ImageVector,
    val accent: Color,
    val isVideo: Boolean
) {
    FOTO("Foto", "JPG", Icons.Default.PhotoCamera, Color.White, false),
    VIDEO("Video", "720p 60fps", Icons.Default.Videocam, Color(0xFFFF5252), true),
    SLOW_MO("Slow-mo", "120fps", Icons.Default.SlowMotionVideo, Color(0xFFFFB300), true),
    TIMELAPSE("Timelapse", "2 dtk/frame", Icons.Default.Timelapse, Color(0xFF69F0AE), true),
    MALAM("Malam", "ISO tinggi", Icons.Default.NightsStay, Color(0xFF7C4DFF), false),
    PANORAMA("Panorama", "180°", Icons.Default.Panorama, Color(0xFF00E5FF), false)
}

/**
 * Kontrol kamera layar FPV: pemilih mode animasi + tombol rekam/foto yang berubah bentuk.
 * Catatan: ini kontrol tampilan; penyimpanan hasil ke galeri belum terhubung ke dekoder video.
 */
@Composable
fun CameraControls(
    videoStats: VideoFeedStats,
    isLive: Boolean,
    onShowToast: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf(CameraMode.FOTO) }
    var showModes by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var seconds by remember { mutableStateOf(0) }
    var photoCount by remember { mutableStateOf(0) }
    var frameCount by remember { mutableStateOf(0) }
    var pressed by remember { mutableStateOf(false) }
    val flash = remember { Animatable(0f) }
    val panoProgress = remember { Animatable(0f) }
    var panoRunning by remember { mutableStateOf(false) }

    fun fireFlash() {
        scope.launch {
            flash.snapTo(0.85f)
            flash.animateTo(0f, tween(380))
        }
    }

    // Pewaktu rekaman
    LaunchedEffect(recording) {
        if (recording) {
            seconds = 0
            while (true) {
                delay(1000)
                seconds += 1
            }
        }
    }
    // Timelapse: ambil frame tiap 2 detik selama aktif
    LaunchedEffect(recording, mode) {
        if (recording && mode == CameraMode.TIMELAPSE) {
            frameCount = 0
            while (true) {
                delay(2000)
                frameCount += 1
                fireFlash()
            }
        }
    }

    val accent by animateColorAsState(
        targetValue = if (recording) AviationRed else mode.accent,
        animationSpec = tween(350),
        label = "accent"
    )
    val innerColor by animateColorAsState(
        targetValue = if (recording || mode == CameraMode.VIDEO || mode == CameraMode.SLOW_MO) AviationRed else Color.White,
        animationSpec = tween(300),
        label = "innerColor"
    )
    val innerSize by animateDpAsState(if (recording) 22.dp else 44.dp, tween(260), label = "innerSize")
    val innerCorner by animateDpAsState(if (recording) 5.dp else 22.dp, tween(260), label = "innerCorner")
    val pressScale by animateFloatAsState(
        targetValue = if (pressed) 0.82f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "pressScale"
    )

    val infinite = rememberInfiniteTransition(label = "camInfinite")
    val recBlink by infinite.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(650, easing = LinearEasing), RepeatMode.Reverse),
        label = "recBlink"
    )
    val spin by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing)),
        label = "spin"
    )

    fun selectMode(m: CameraMode) {
        if (m == mode) {
            showModes = false
            return
        }
        recording = false
        mode = m
        showModes = false
        onShowToast("Mode kamera: ${m.label} (${m.spec})")
    }

    fun onShutter() {
        if (!isLive) {
            onShowToast("Penerima video FPV belum aktif")
            return
        }
        pressed = true
        scope.launch {
            delay(130)
            pressed = false
        }
        when (mode) {
            CameraMode.FOTO, CameraMode.MALAM -> {
                photoCount += 1
                fireFlash()
                onShowToast("Foto #$photoCount diambil (belum disimpan ke galeri)")
            }
            CameraMode.VIDEO, CameraMode.SLOW_MO, CameraMode.TIMELAPSE -> {
                recording = !recording
                onShowToast(
                    if (recording) "Perekaman ${mode.label} dimulai"
                    else "Perekaman ${mode.label} dihentikan (belum disimpan ke galeri)"
                )
            }
            CameraMode.PANORAMA -> {
                if (!panoRunning) {
                    panoRunning = true
                    scope.launch {
                        panoProgress.snapTo(0f)
                        panoProgress.animateTo(1f, tween(3200, easing = LinearEasing))
                        fireFlash()
                        onShowToast("Panorama selesai (belum disimpan ke galeri)")
                        panoProgress.snapTo(0f)
                        panoRunning = false
                    }
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Kilatan putih saat foto/frame diambil
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = flash.value }
                .background(Color.White)
        )

        Row(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Daftar mode: meluncur masuk dari kanan
            AnimatedVisibility(
                visible = showModes,
                enter = slideInHorizontally(tween(260)) { it / 2 } + fadeIn(tween(220)) + expandVertically(tween(260)),
                exit = slideOutHorizontally(tween(200)) { it / 2 } + fadeOut(tween(160)) + shrinkVertically(tween(200))
            ) {
                Column(
                    modifier = Modifier.padding(end = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    CameraMode.values().forEach { m ->
                        val selected = m == mode
                        val bg by animateColorAsState(
                            targetValue = if (selected) m.accent.copy(alpha = 0.30f) else Color(0x66000000),
                            animationSpec = tween(250),
                            label = "pillBg"
                        )
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(bg)
                                .border(
                                    1.dp,
                                    if (selected) m.accent else Color(0x33FFFFFF),
                                    RoundedCornerShape(16.dp)
                                )
                                .clickable { selectMode(m) }
                                .padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = m.icon,
                                contentDescription = m.label,
                                tint = if (selected) m.accent else Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = m.label,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Tombol mode: ikon berganti dengan animasi zoom + pudar
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x66000000))
                        .border(1.dp, accent.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                        .clickable { showModes = !showModes },
                    contentAlignment = Alignment.Center
                ) {
                    AnimatedContent(
                        targetState = mode,
                        transitionSpec = {
                            (fadeIn(tween(220)) + scaleIn(initialScale = 0.5f, animationSpec = tween(260))) togetherWith
                                (fadeOut(tween(140)) + scaleOut(targetScale = 0.5f, animationSpec = tween(140)))
                        },
                        label = "modeIcon"
                    ) { m ->
                        Icon(
                            imageVector = m.icon,
                            contentDescription = m.label,
                            tint = m.accent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Tombol rana: cincin berganti warna, bagian dalam berubah lingkaran <-> kotak
                Box(
                    modifier = Modifier.size(66.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (recording && mode == CameraMode.TIMELAPSE) {
                        Canvas(modifier = Modifier.size(66.dp).rotate(spin)) {
                            drawArc(
                                color = accent,
                                startAngle = 0f,
                                sweepAngle = 80f,
                                useCenter = false,
                                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                    }
                    if (panoRunning) {
                        Canvas(modifier = Modifier.size(66.dp)) {
                            drawArc(
                                color = accent,
                                startAngle = -90f,
                                sweepAngle = 360f * panoProgress.value,
                                useCenter = false,
                                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                    }
                    Box(
                        modifier = Modifier
                            .size(58.dp)
                            .graphicsLayer {
                                scaleX = pressScale
                                scaleY = pressScale
                            }
                            .clip(CircleShape)
                            .border(3.dp, accent, CircleShape)
                            .clickable { onShutter() },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(innerSize)
                                .clip(RoundedCornerShape(innerCorner))
                                .background(innerColor)
                        )
                    }
                }

                // Keterangan status di bawah tombol, berganti dengan animasi
                val statusText = when {
                    recording && mode == CameraMode.TIMELAPSE -> "FRAME $frameCount"
                    recording -> String.format("%02d:%02d", seconds / 60, seconds % 60)
                    panoRunning -> "GESER..."
                    mode == CameraMode.FOTO || mode == CameraMode.MALAM ->
                        if (photoCount > 0) "FOTO $photoCount" else mode.spec
                    else -> mode.spec
                }
                AnimatedContent(
                    targetState = statusText,
                    transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(120)) },
                    label = "statusText"
                ) { t ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (recording) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .graphicsLayer { alpha = recBlink }
                                    .clip(CircleShape)
                                    .background(AviationRed)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Text(
                            text = t,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Info umpan video (resolusi/fps nyata bila penerima aktif)
                if (videoStats.isReceiving && videoStats.resolutionWidth > 0) {
                    Text(
                        text = "${videoStats.resolutionWidth}x${videoStats.resolutionHeight} ${videoStats.fps}fps",
                        color = Color(0xFFB0BEC5),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
