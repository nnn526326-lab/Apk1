package com.example.repository

import android.content.Context
import com.example.diagnostics.DiagnosticsLogger
import com.example.model.ArmingState
import com.example.model.BaroTelemetry
import com.example.model.BatteryTelemetry
import com.example.model.DeviceCenterStatus
import com.example.model.FcStatus
import com.example.model.FlightLogEntry
import com.example.model.FlightMode
import com.example.model.GpsTelemetry
import com.example.model.ImuTelemetry
import com.example.model.LogSeverity
import com.example.model.NexendDeviceType
import com.example.model.OpticalFlowTelemetry
import com.example.model.RcTelemetry
import com.example.model.SensorHealth
import com.example.model.ToFTelemetry
import com.example.model.VideoFeedStats
import com.example.protocol.NexendPacket
import com.example.protocol.NexendPacketParser
import com.example.protocol.NexendCommands
import com.example.protocol.NexendProtocol
import com.example.simulation.DroneSimulationEngine
import com.example.usb.NexendUsbManager
import com.example.video.VideoReceiverManager
import com.example.video.NetworkCameraDiscovery
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import java.nio.ByteOrder

private fun looksLikeFcName(name: String?): Boolean {
    val n = name?.lowercase() ?: return false
    if (n.contains("remote")) return false
    return n.contains("flight") || n.contains("-fc") || n.contains(" fc") ||
        n.contains("fc-") || n.contains("configurator")
}

private fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Float {
    val r = 6371000.0
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = sin(dLat / 2) * sin(dLat / 2) +
        cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2) * sin(dLon / 2)
    return (r * 2 * atan2(sqrt(a), sqrt(1 - a))).toFloat()
}

data class DroneSystemState(
    val fcStatus: FcStatus = FcStatus(),
    val rcTelemetry: RcTelemetry = RcTelemetry(),
    val battery: BatteryTelemetry = BatteryTelemetry(),
    val gps: GpsTelemetry = GpsTelemetry(),
    val imu: ImuTelemetry = ImuTelemetry(),
    val baro: BaroTelemetry = BaroTelemetry(),
    val tof: ToFTelemetry = ToFTelemetry(),
    val opticalFlow: OpticalFlowTelemetry = OpticalFlowTelemetry(),
    val sensorHealth: SensorHealth = SensorHealth(),
    /** Ketinggian RTH maksimal (m) yang DIKONFIRMASI FC lewat ACK/read-back; null = belum pernah dibaca. */
    val rthMaxAltM: Int? = null,
    val videoStats: VideoFeedStats = VideoFeedStats(),
    val networkCameraDevices: List<String> = emptyList(),
    val deviceStatus: DeviceCenterStatus = DeviceCenterStatus(),
    val isSimulationMode: Boolean = false,
    val isFcStale: Boolean = false,
    val isRcStale: Boolean = false,
    /** Heading kompas (derajat) bila FC mengirim MSG_MAG; null = tidak ada. */
    val magHeadingDeg: Float? = null,
    /** FC memperkenalkan diri sebagai perangkat langsung (MSG_HELLO peran 2). */
    val fcDirectByHello: Boolean = false,
    /** Simulasi: anggap drone tersambung lewat kabel (untuk mencoba Configurator). */
    val simulatedCable: Boolean = false
) {
    /** Drone (FC) tersambung langsung lewat kabel USB, bukan lewat remote. */
    val isFcDirectCable: Boolean
        get() = fcDirectByHello || looksLikeFcName(deviceStatus.remoteController?.productName)

    /** Syarat satu-satunya untuk masuk ke Nexend Configurator (tidak bisa dibuka manual). */
    val canOpenConfigurator: Boolean
        get() = if (isSimulationMode) simulatedCable else (deviceStatus.remoteReady && isFcDirectCable)

    /** Remote (RP2040) terhubung lewat OTG. Satu-satunya syarat untuk membuka tampilan kamera. */
    val isRemoteConnected: Boolean get() = rcTelemetry.isConnected

    /** Drone/FC benar-benar menjawab lewat remote (telemetri masuk). */
    val isDroneLinked: Boolean get() = fcStatus.isConnected

    val canOpenCameraView: Boolean get() = isSimulationMode || isRemoteConnected
}

class DroneRepository(
    private val context: Context
) {
    private val repoScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val diagnosticsLogger = DiagnosticsLogger()
    private val networkCameraDiscovery = NetworkCameraDiscovery(context)
    val videoManager = VideoReceiverManager(repoScope) { severity, msg ->
        diagnosticsLogger.log(
            when (severity) {
                "ERROR" -> LogSeverity.ERROR
                "WARN" -> LogSeverity.WARN
                else -> LogSeverity.INFO
            },
            "VIDEO",
            msg
        )
    }

    private val simulationEngine = DroneSimulationEngine(repoScope)

    private val packetParser = NexendPacketParser(
        onPacketReceived = { packet -> handleHardwarePacket(packet) },
        onError = { err -> diagnosticsLogger.log(LogSeverity.WARN, "PROTOCOL", err) }
    )

    private val usbManager = NexendUsbManager(
        context = context,
        scope = repoScope,
        onDataReceived = { devType, data ->
            packetParser.parseBytes(data)
        },
        onLog = { severity, msg ->
            diagnosticsLogger.log(
                when (severity) {
                    "ERROR" -> LogSeverity.ERROR
                    "WARN" -> LogSeverity.WARN
                    else -> LogSeverity.INFO
                },
                "USB",
                msg
            )
        }
    )

    private val _systemState = MutableStateFlow(DroneSystemState())
    val systemState: StateFlow<DroneSystemState> = _systemState.asStateFlow()

    init {
        diagnosticsLogger.log(LogSeverity.INFO, "SYSTEM", "NEXEND FLY Repository Initialized")
        networkCameraDiscovery.start()
        repoScope.launch {
            networkCameraDiscovery.devices.collect { devices ->
                _systemState.update { it.copy(networkCameraDevices = devices) }
                if (devices.isNotEmpty()) diagnosticsLogger.log(LogSeverity.INFO, "NETWORK_CAMERA", "Ditemukan ${devices.size} layanan kamera jaringan")
            }
        }

        // Start staleness monitor and state merger
        repoScope.launch {
            while (isActive) {
                delay(200)
                updateStalenessAndMerge()
            }
        }

        // Forward USB device list changes
        repoScope.launch {
            usbManager.deviceStatus.collect { devStatus ->
                _systemState.update { it.copy(deviceStatus = devStatus) }
                updateStalenessAndMerge()
            }
        }

        // Forward video stats
        repoScope.launch {
            videoManager.videoStats.collect { vStats ->
                _systemState.update { it.copy(videoStats = vStats) }
            }
        }

        // Forward simulation state when simulation mode is active
        repoScope.launch {
            simulationEngine.simState.collect { sim ->
                _systemState.update { cur ->
                    if (!cur.isSimulationMode) cur else cur.copy(
                        fcStatus = sim.fcStatus,
                        rcTelemetry = sim.rcTelemetry,
                        battery = sim.battery,
                        gps = sim.gps,
                        imu = sim.imu,
                        baro = sim.baro,
                        tof = sim.tof,
                        opticalFlow = sim.opticalFlow,
                        sensorHealth = sim.sensorHealth,
                        isFcStale = false,
                        isRcStale = false
                    )
                }
            }
        }
    }

    fun setSimulationMode(enabled: Boolean) {
        if (_systemState.value.isSimulationMode == enabled) return

        _systemState.update { it.copy(isSimulationMode = enabled, simulatedCable = if (enabled) it.simulatedCable else false) }
        if (enabled) {
            diagnosticsLogger.log(LogSeverity.INFO, "SIMULATION", "Simulation Mode ACTIVATED")
            simulationEngine.start()
            videoManager.startStreamMonitoring(isSimulation = true)
        } else {
            diagnosticsLogger.log(LogSeverity.INFO, "HARDWARE", "Hardware Mode ACTIVATED - Connecting to USB interfaces")
            simulationEngine.stop()
            videoManager.startStreamMonitoring(isSimulation = false)
            // Reset to unlinked hardware states until packets arrive
            updateStalenessAndMerge()
        }
    }

    fun setSimulatedCable(enabled: Boolean) {
        if (enabled) setSimulationMode(true)
        _systemState.update { it.copy(simulatedCable = enabled && it.isSimulationMode) }
    }

    fun toggleSimulatedArm() {
        if (_systemState.value.isSimulationMode) {
            simulationEngine.toggleArm()
            diagnosticsLogger.log(LogSeverity.INFO, "SIMULATION", "Toggled simulated drone arming")
        }
    }

    fun refreshUsbDevices() {
        usbManager.refreshDevices(autoRequest = true)
    }

    private val pendingAcks =
        java.util.concurrent.ConcurrentHashMap<Int, kotlinx.coroutines.CompletableDeferred<Int>>()
    private val commandSeq = java.util.concurrent.atomic.AtomicInteger(0)

    /**
     * Kirim perintah konfigurator ke FC lewat kabel USB, lalu tunggu ACK (maks 1,5 dtk).
     * Mode simulasi langsung dianggap berhasil. Perintah yang berisiko ditolak bila drone ARMED.
     */
    fun sendCommand(
        cmd: Byte,
        args: ByteArray = ByteArray(0),
        label: String,
        requireDisarmed: Boolean = true,
        onResult: (Boolean, String) -> Unit
    ) {
        val st = _systemState.value
        if (requireDisarmed && st.fcStatus.armingState == ArmingState.ARMED) {
            val msg = "DITOLAK: $label tidak boleh dijalankan saat drone ARMED"
            diagnosticsLogger.log(LogSeverity.CRITICAL, "SAFETY", msg)
            onResult(false, msg)
            return
        }
        if (st.isSimulationMode) {
            diagnosticsLogger.log(LogSeverity.INFO, "SIMULATION", "$label (simulasi)")
            onResult(true, "$label berhasil (simulasi)")
            return
        }
        if (!st.deviceStatus.remoteReady) {
            onResult(false, "Kabel USB belum terhubung")
            return
        }
        if (!st.fcStatus.isConnected) {
            onResult(false, "FC belum menjawab, periksa kabel dan daya drone")
            return
        }
        repoScope.launch {
            val key = cmd.toInt() and 0xFF
            val waiter = kotlinx.coroutines.CompletableDeferred<Int>()
            pendingAcks[key] = waiter
            val seq = (commandSeq.incrementAndGet() and 0xFF).toByte()
            val payload = byteArrayOf(cmd) + args
            val packet = NexendProtocol.buildPacket(NexendProtocol.MSG_COMMAND_REQ, seq, payload)
            val sent = kotlinx.coroutines.withContext(Dispatchers.IO) { usbManager.sendData(packet) }
            if (!sent) {
                pendingAcks.remove(key)
                diagnosticsLogger.log(LogSeverity.ERROR, "CMD", "$label: gagal menulis ke USB")
                onResult(false, "$label gagal: tidak bisa menulis ke USB")
                return@launch
            }
            val status = kotlinx.coroutines.withTimeoutOrNull(1500) { waiter.await() }
            pendingAcks.remove(key)
            when {
                status == null -> {
                    diagnosticsLogger.log(LogSeverity.WARN, "CMD", "$label: tidak ada ACK dari FC")
                    onResult(false, "$label terkirim, tetapi FC tidak membalas (firmware mungkin belum mendukung)")
                }
                status == 0 -> {
                    diagnosticsLogger.log(LogSeverity.INFO, "CMD", "$label: OK")
                    onResult(true, "$label berhasil")
                }
                else -> {
                    val why = when {
                        cmd == NexendCommands.SET_RTH_ALT && status == 2 -> "drone harus DISARM"
                        cmd == NexendCommands.SET_RTH_ALT && status == 3 -> "di luar rentang ${NexendCommands.RTH_ALT_MIN_M}-${NexendCommands.RTH_ALT_MAX_M} m"
                        cmd == NexendCommands.SET_RTH_ALT && status == 4 -> "FC gagal menyimpan"
                        else -> "kode $status"
                    }
                    diagnosticsLogger.log(LogSeverity.ERROR, "CMD", "$label: ditolak FC ($why)")
                    onResult(false, "$label ditolak FC ($why)")
                }
            }
        }
    }

    fun requestArm(onResult: (Boolean, String) -> Unit) {
        val state = _systemState.value
        if (state.isSimulationMode) {
            simulationEngine.toggleArm()
            onResult(true, "ARM simulasi diproses")
            return
        }
        if (!state.rcTelemetry.isConnected || !state.fcStatus.isConnected) {
            onResult(false, "Remote dan FC harus terhubung sebelum ARM")
            return
        }
        if (state.fcStatus.armingState != ArmingState.DISARMED) {
            onResult(false, "ARM ditolak: status FC bukan DISARMED")
            return
        }
        sendCommand(NexendCommands.REMOTE_ARM, label = "ARM / TAKE-OFF", requireDisarmed = true, onResult = onResult)
    }

    fun requestRth(onResult: (Boolean, String) -> Unit) {
        val state = _systemState.value
        if (state.isSimulationMode) {
            onResult(true, "RTH simulasi diproses")
            return
        }
        if (!state.rcTelemetry.isConnected || !state.fcStatus.isConnected || state.fcStatus.armingState != ArmingState.ARMED) {
            onResult(false, "RTH memerlukan remote dan FC terhubung serta drone ARMED")
            return
        }
        if (!state.gps.hasFix || !state.gps.isHomeSet) {
            onResult(false, "RTH ditolak: GPS belum FIX atau titik HOME belum tersimpan")
            return
        }
        sendCommand(NexendCommands.REMOTE_RTH, label = "RETURN TO HOME", requireDisarmed = false, onResult = onResult)
    }

    fun requestLand(onResult: (Boolean, String) -> Unit) {
        val state = _systemState.value
        if (state.isSimulationMode) {
            onResult(true, "LAND simulasi diproses")
            return
        }
        if (!state.rcTelemetry.isConnected || !state.fcStatus.isConnected || state.fcStatus.armingState != ArmingState.ARMED) {
            onResult(false, "LAND memerlukan remote dan FC terhubung serta drone ARMED")
            return
        }
        // Existing protocol definition: SET_FAILSAFE arg 0 = controlled LAND, not motor cut.
        sendCommand(NexendCommands.SET_FAILSAFE, byteArrayOf(0), "LAND terkendali", requireDisarmed = false, onResult = onResult)
    }

    fun requestUsbPermission(deviceId: Int) {
        usbManager.requestPermissionForDevice(deviceId)
    }

    private fun handleHardwarePacket(packet: NexendPacket) {
        val now = System.currentTimeMillis()
        // Paket hanya relevan bila remote memang terbuka lewat USB
        if (!_systemState.value.isSimulationMode && !_systemState.value.deviceStatus.remoteReady) return

        when (packet.msgId) {
            NexendProtocol.MSG_HEARTBEAT -> {
                // Heartbeat berasal dari remote. Bit0 payload[0] = "link ke drone/FC aktif".
                // Heartbeat tanpa payload hanya membuktikan remote hidup, BUKAN bahwa FC terhubung.
                val fcLink = packet.payload.isNotEmpty() && (packet.payload[0].toInt() and 0x01) != 0
                _systemState.update { s ->
                    s.copy(
                        rcTelemetry = s.rcTelemetry.copy(isConnected = true, lastUpdateMs = now),
                        fcStatus = if (fcLink) s.fcStatus.copy(isConnected = true, lastUpdateMs = now) else s.fcStatus
                    )
                }
            }
            NexendProtocol.MSG_TELEMETRY -> {
                if (packet.payload.size >= 14) {
                    val bb = ByteBuffer.wrap(packet.payload).order(ByteOrder.LITTLE_ENDIAN)
                    val roll = bb.short / 10.0f
                    val pitch = bb.short / 10.0f
                    val yaw = bb.short / 10.0f
                    val alt = bb.short / 10.0f
                    val vSpeed = bb.short / 10.0f
                    val hSpeed = bb.short / 10.0f
                    val armedByte = bb.get().toInt()
                    val modeByte = bb.get().toInt()

                    _systemState.update { s ->
                        s.copy(
                            fcStatus = s.fcStatus.copy(
                                isConnected = true,
                                armingState = if (armedByte == 1) ArmingState.ARMED else ArmingState.DISARMED,
                                flightMode = parseFlightMode(modeByte),
                                horizontalSpeedMs = hSpeed,
                                lastUpdateMs = now
                            ),
                            imu = s.imu.copy(
                                rollDeg = roll,
                                pitchDeg = pitch,
                                yawDeg = yaw,
                                isValid = true,
                                lastUpdateMs = now
                            ),
                            baro = s.baro.copy(
                                altitudeMeters = alt,
                                verticalSpeedMs = vSpeed,
                                isValid = true,
                                lastUpdateMs = now
                            )
                        )
                    }
                }
            }
            NexendProtocol.MSG_HELLO -> {
                if (packet.payload.isNotEmpty()) {
                    val role = packet.payload[0].toInt() and 0xFF
                    _systemState.update { it.copy(fcDirectByHello = (role == 2)) }
                }
            }
            NexendProtocol.MSG_IMU -> {
                if (packet.payload.size >= 12) {
                    val bb = ByteBuffer.wrap(packet.payload).order(ByteOrder.LITTLE_ENDIAN)
                    val gx = bb.short / 10.0f
                    val gy = bb.short / 10.0f
                    val gz = bb.short / 10.0f
                    val ax = bb.short / 1000.0f
                    val ay = bb.short / 1000.0f
                    val az = bb.short / 1000.0f
                    _systemState.update { s ->
                        s.copy(
                            fcStatus = s.fcStatus.copy(isConnected = true, lastUpdateMs = now),
                            imu = s.imu.copy(
                                gyroXDegPerSec = gx, gyroYDegPerSec = gy, gyroZDegPerSec = gz,
                                accelXG = ax, accelYG = ay, accelZG = az,
                                isValid = true, lastUpdateMs = now
                            )
                        )
                    }
                }
            }
            NexendProtocol.MSG_GPS -> {
                if (packet.payload.size >= 13) {
                    val bb = ByteBuffer.wrap(packet.payload).order(ByteOrder.LITTLE_ENDIAN)
                    val lat = bb.int / 1.0e7
                    val lon = bb.int / 1.0e7
                    val alt = bb.short / 10.0f
                    val sats = bb.get().toInt() and 0xFF
                    val fix = bb.get().toInt() and 0xFF
                    val hdop = (bb.get().toInt() and 0xFF) / 10.0f
                    _systemState.update { s ->
                        val hasFix = fix >= 2
                        val homeSet = s.gps.isHomeSet
                        val homeLat = if (!homeSet && hasFix) lat else s.gps.homeLatitude
                        val homeLon = if (!homeSet && hasFix) lon else s.gps.homeLongitude
                        val isHome = homeSet || hasFix
                        s.copy(
                            gps = GpsTelemetry(
                                hasFix = hasFix,
                                fixType = when (fix) { 3 -> "3D FIX"; 2 -> "2D FIX"; else -> "NO FIX" },
                                satellites = sats,
                                latitude = lat,
                                longitude = lon,
                                altitudeMeters = alt,
                                hdop = hdop,
                                distanceToHomeMeters = if (isHome && hasFix) distanceMeters(homeLat, homeLon, lat, lon) else 0f,
                                homeLatitude = homeLat,
                                homeLongitude = homeLon,
                                isHomeSet = isHome,
                                isValid = true,
                                lastUpdateMs = now
                            )
                        )
                    }
                }
            }
            NexendProtocol.MSG_SENSOR_HEALTH -> {
                if (packet.payload.size >= 2) {
                    val det = packet.payload[0].toInt() and 0xFF
                    val ok = packet.payload[1].toInt() and 0xFF
                    fun d(i: Int) = ((det shr i) and 1) == 1
                    fun h(i: Int) = ((ok shr i) and 1) == 1
                    _systemState.update { s ->
                        s.copy(
                            sensorHealth = SensorHealth(
                                imuDetected = d(0), imuHealthy = h(0),
                                baroDetected = d(1), baroHealthy = h(1),
                                magDetected = d(2), magHealthy = h(2),
                                gpsDetected = d(3), gpsHealthy = h(3),
                                tofDetected = d(4), tofHealthy = h(4),
                                opticalFlowDetected = d(5), opticalFlowHealthy = h(5)
                            )
                        )
                    }
                }
            }
            NexendProtocol.MSG_RANGE -> {
                if (packet.payload.size >= 5) {
                    val bb = ByteBuffer.wrap(packet.payload).order(ByteOrder.LITTLE_ENDIAN)
                    val tofCm = bb.short.toInt() and 0xFFFF
                    val fx = bb.get().toInt()
                    val fy = bb.get().toInt()
                    val q = bb.get().toInt() and 0xFF
                    val out = tofCm == 0xFFFF
                    _systemState.update { s ->
                        s.copy(
                            tof = ToFTelemetry(
                                distanceCm = if (out) 0 else tofCm,
                                isValid = !out,
                                isOutOfRange = out,
                                lastUpdateMs = now
                            ),
                            opticalFlow = OpticalFlowTelemetry(
                                motionX = fx / 10.0f,
                                motionY = fy / 10.0f,
                                surfaceQuality = q,
                                isValid = q > 20
                            )
                        )
                    }
                }
            }
            NexendProtocol.MSG_MAG -> {
                if (packet.payload.size >= 2) {
                    val bb = ByteBuffer.wrap(packet.payload).order(ByteOrder.LITTLE_ENDIAN)
                    var hdg = bb.short / 10.0f
                    hdg = ((hdg % 360f) + 360f) % 360f
                    _systemState.update { it.copy(magHeadingDeg = hdg) }
                }
            }
            NexendProtocol.MSG_COMMAND_ACK -> {
                if (packet.payload.size >= 2) {
                    val id = packet.payload[0].toInt() and 0xFF
                    val status = packet.payload[1].toInt() and 0xFF
                    // ACK ketinggian RTH: [cmd][status][alt hi][alt lo] (big-endian). Nilai = read-back sebenarnya dari FC.
                    if ((id == (NexendCommands.SET_RTH_ALT.toInt() and 0xFF) ||
                         id == (NexendCommands.GET_RTH_ALT.toInt() and 0xFF)) && packet.payload.size >= 4) {
                        val alt = ((packet.payload[2].toInt() and 0xFF) shl 8) or (packet.payload[3].toInt() and 0xFF)
                        if (alt in 1..1000) _systemState.update { it.copy(rthMaxAltM = alt) }
                    }
                    pendingAcks[id]?.complete(status)
                }
            }
            NexendProtocol.MSG_BATTERY -> {
                if (packet.payload.size >= 7) {
                    val bb = ByteBuffer.wrap(packet.payload).order(ByteOrder.LITTLE_ENDIAN)
                    val voltage = bb.short / 100.0f
                    val current = bb.short / 100.0f
                    val mah = bb.short.toInt()
                    val pct = bb.get().toInt() and 0xFF

                    _systemState.update { s ->
                        s.copy(
                            // Baterai drone => bukti FC menjawab
                            fcStatus = s.fcStatus.copy(isConnected = true, lastUpdateMs = now),
                            battery = BatteryTelemetry(
                                voltage = voltage,
                                currentAmps = current,
                                consumedMah = mah,
                                remainingPercent = pct,
                                isLowBattery = pct < 20,
                                isCriticalBattery = pct < 10,
                                isValid = true,
                                lastUpdateMs = now
                            )
                        )
                    }
                }
            }
            NexendProtocol.MSG_RC_CHANNELS -> {
                if (packet.payload.size >= 10) {
                    val bb = ByteBuffer.wrap(packet.payload).order(ByteOrder.LITTLE_ENDIAN)
                    val thr = bb.get().toInt() and 0xFF
                    val roll = bb.get().toInt()
                    val pitch = bb.get().toInt()
                    val yaw = bb.get().toInt()
                    val swA = bb.get().toInt()
                    val swB = bb.get().toInt()
                    val swC = bb.get().toInt()
                    val swD = bb.get().toInt()
                    val rssi = bb.get().toInt()
                    val loss = bb.get().toInt()

                    _systemState.update { s ->
                        s.copy(
                            rcTelemetry = RcTelemetry(
                                isConnected = true,
                                throttlePercent = thr,
                                rollStickPercent = roll,
                                pitchStickPercent = pitch,
                                yawStickPercent = yaw,
                                switchA = swA,
                                switchB = swB,
                                switchC = swC,
                                switchD = swD,
                                rssiDbm = rssi,
                                packetLossPercent = loss.toFloat(),
                                lastUpdateMs = now
                            )
                        )
                    }
                }
            }
        }
    }

    private fun parseFlightMode(mode: Int): FlightMode = when (mode) {
        1 -> FlightMode.MANUAL
        2 -> FlightMode.STABILIZE
        3 -> FlightMode.ALT_HOLD
        4 -> FlightMode.POS_HOLD
        5 -> FlightMode.RTH
        6 -> FlightMode.ACRO
        else -> FlightMode.NA
    }

    /**
     * Aturan koneksi (mode hardware):
     *  - REMOTE terhubung  <=> RP2040 terdeteksi, izin USB diberikan, dan port data terbuka.
     *  - DRONE/FC terhubung <=> remote terhubung DAN telemetri FC masih masuk (< 4 dtk).
     *    Remote tercolok tapi FC tidak menjawab => di aplikasi drone tetap "tidak terhubung".
     */
    private fun updateStalenessAndMerge() {
        _systemState.update { s ->
            if (s.isSimulationMode) return@update s

            val now = System.currentTimeMillis()
            val remoteReady = s.deviceStatus.remoteReady

            if (!remoteReady) {
                // Remote tidak ada => semuanya putus
                return@update s.copy(
                    rcTelemetry = RcTelemetry(isConnected = false),
                    fcStatus = FcStatus(isConnected = false),
                    battery = BatteryTelemetry(isValid = false),
                    gps = GpsTelemetry(isValid = false),
                    imu = ImuTelemetry(isValid = false),
                    baro = BaroTelemetry(isValid = false),
                    isFcStale = false,
                    isRcStale = false,
                    magHeadingDeg = null,
                    fcDirectByHello = false
                )
            }

            val fcAge = now - s.fcStatus.lastUpdateMs
            val rcAge = now - s.rcTelemetry.lastUpdateMs
            val fcLinked = s.fcStatus.lastUpdateMs > 0L && fcAge < 4000
            val rcHasData = s.rcTelemetry.lastUpdateMs > 0L

            val next = s.copy(
                isFcStale = fcLinked && fcAge > 1500,
                isRcStale = rcHasData && rcAge > 1500,
                rcTelemetry = s.rcTelemetry.copy(isConnected = true),
                fcStatus = s.fcStatus.copy(isConnected = fcLinked)
            )
            if (fcLinked) next else next.copy(
                battery = next.battery.copy(isValid = false),
                imu = next.imu.copy(isValid = false),
                baro = next.baro.copy(isValid = false),
                gps = next.gps.copy(isValid = false)
            )
        }
    }

    fun cleanup() {
        networkCameraDiscovery.stop()
        usbManager.cleanup()
        videoManager.stopStream()
        simulationEngine.stop()
    }
}
