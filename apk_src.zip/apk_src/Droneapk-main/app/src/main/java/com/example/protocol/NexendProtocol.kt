package com.example.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder

object NexendProtocol {
    const val SYNC_1: Byte = 0xAA.toByte()
    const val SYNC_2: Byte = 0x55.toByte()

    const val MSG_HELLO: Byte = 0x01
    const val MSG_HEARTBEAT: Byte = 0x02
    const val MSG_TELEMETRY: Byte = 0x10
    const val MSG_IMU: Byte = 0x11
    const val MSG_BARO: Byte = 0x12
    const val MSG_GPS: Byte = 0x13
    const val MSG_BATTERY: Byte = 0x14
    const val MSG_SENSOR_HEALTH: Byte = 0x15
    const val MSG_RANGE: Byte = 0x16   // ToF + optical flow
    const val MSG_MAG: Byte = 0x17     // heading kompas
    const val MSG_RC_CHANNELS: Byte = 0x20
    const val MSG_COMMAND_REQ: Byte = 0x40
    const val MSG_COMMAND_ACK: Byte = 0x41

    /**
     * Computes CRC16-CCITT (poly 0x1021, init 0xFFFF)
     */
    fun calculateCrc16(bytes: ByteArray, offset: Int = 0, length: Int = bytes.size): Int {
        var crc = 0xFFFF
        for (i in offset until (offset + length)) {
            val b = bytes[i].toInt() and 0xFF
            crc = crc xor (b shl 8)
            for (j in 0 until 8) {
                crc = if ((crc and 0x8000) != 0) {
                    (crc shl 1) xor 0x1021
                } else {
                    crc shl 1
                }
                crc = crc and 0xFFFF
            }
        }
        return crc
    }

    /**
     * Builds a framed packet with header, seq, length, payload, and CRC16
     */
    fun buildPacket(msgId: Byte, seq: Byte, payload: ByteArray): ByteArray {
        val payloadLen = payload.size.coerceAtMost(255)
        val packet = ByteArray(2 + 1 + 1 + 1 + payloadLen + 2)
        packet[0] = SYNC_1
        packet[1] = SYNC_2
        packet[2] = msgId
        packet[3] = seq
        packet[4] = payloadLen.toByte()

        System.arraycopy(payload, 0, packet, 5, payloadLen)

        // CRC calculated over msgId, seq, length, and payload
        val crc = calculateCrc16(packet, 2, 3 + payloadLen)
        packet[5 + payloadLen] = ((crc shr 8) and 0xFF).toByte()
        packet[6 + payloadLen] = (crc and 0xFF).toByte()

        return packet
    }
}

data class NexendPacket(
    val msgId: Byte,
    val sequence: Int,
    val payload: ByteArray,
    val timestampMs: Long = System.currentTimeMillis()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as NexendPacket
        return msgId == other.msgId && sequence == other.sequence && payload.contentEquals(other.payload)
    }

    override fun hashCode(): Int {
        var result = msgId.toInt()
        result = 31 * result + sequence
        result = 31 * result + payload.contentHashCode()
        return result
    }
}

/**
 * ID perintah konfigurator (dikirim lewat MSG_COMMAND_REQ, payload[0] = ID perintah, sisanya argumen).
 * FC membalas MSG_COMMAND_ACK dengan payload [ID perintah, status] (status 0 = OK).
 * Firmware FC harus mengimplementasikan ID ini agar perintah berfungsi.
 */
object NexendCommands {
    // Remote flight commands defined by NEXEND_LINK_V1 (reserved IDs 0x01..0x03).
    // ARM/DISARM/RTH are forwarded by compatible remote firmware to the flight controller.
    const val REMOTE_ARM: Byte = 0x01
    const val REMOTE_DISARM: Byte = 0x02
    const val REMOTE_RTH: Byte = 0x03
    // ID 0x01..0x03 DIPESAN oleh remote (ARM/DISARM/RTH). Dulu kalibrasi memakai 0x01..0x03 sehingga
    // tombol kalibrasi akan terbaca remote sebagai permintaan ARM/DISARM/RTH. Jangan dipakai lagi.
    const val CAL_ACCEL: Byte = 0x50
    const val CAL_GYRO: Byte = 0x51
    const val CAL_LEVEL: Byte = 0x52
    const val CAL_MAG: Byte = 0x53
    const val MOTOR_TEST: Byte = 0x10      // argumen: [nomor motor 1-4, throttle %]
    const val MOTOR_STOP: Byte = 0x11
    const val SAVE_EEPROM: Byte = 0x20
    const val FACTORY_RESET: Byte = 0x21
    const val REBOOT: Byte = 0x22
    const val BOOTLOADER: Byte = 0x23
    const val BUZZER: Byte = 0x30          // argumen: [1 = nyala, 0 = mati]
    const val SET_HOME: Byte = 0x31
    const val SET_BATTERY: Byte = 0x32     // argumen: [jumlah cell, batas rendah x0.1 V]
    const val SET_FAILSAFE: Byte = 0x33    // argumen: [0 = mendarat, 1 = RTH, 2 = diam]
    const val SET_TRIM: Byte = 0x34        // argumen: [trim roll int8 x0.1 deg, trim pitch int8 x0.1 deg]
    const val SET_ALIGN: Byte = 0x35       // argumen: [0..3 = 0/90/180/270 derajat]
    const val SET_GYRO_FILTER: Byte = 0x36 // argumen: [frekuensi LPF Hz]
    const val SET_TELEM_RATE: Byte = 0x37  // argumen: [laju telemetri Hz]
    const val SET_RTH_ALT: Byte = 0x38     // argumen: [alt m hi][alt m lo] (u16 big-endian). Diteruskan remote -> FC (NEXEND_LINK_V1)
    const val GET_RTH_ALT: Byte = 0x39     // tanpa argumen; ACK: [cmd][status][alt hi][alt lo]
    const val RTH_ALT_MIN_M = 10           // harus sama dgn lim::RTH_MAX_ALT_MIN di FC
    const val RTH_ALT_MAX_M = 120          // harus sama dgn lim::RTH_MAX_ALT_MAX di FC
}

/*
 * Format payload telemetri tambahan (little-endian) yang dibaca aplikasi bila FC mengirimnya:
 *  MSG_HELLO         [peran u8]  1 = remote, 2 = FC langsung (kabel -> Nexend Configurator)
 *  MSG_IMU           gx,gy,gz i16 (x0.1 deg/s), ax,ay,az i16 (mG)                       = 12 byte
 *  MSG_GPS           lat i32 (1e-7 deg), lon i32, alt i16 (x0.1 m), sat u8, fix u8, hdop u8 (x0.1) = 13 byte
 *  MSG_SENSOR_HEALTH [terdeteksi u8][sehat u8]  bit0 IMU, 1 baro, 2 kompas, 3 GPS, 4 ToF, 5 flow
 *  MSG_RANGE         tof_cm u16 (0xFFFF = di luar jangkauan), flowX i8, flowY i8, kualitas u8 = 5 byte
 *  MSG_MAG           heading i16 (x0.1 deg)                                              = 2 byte
 */
