package com.example.ui.sheets

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Build
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ArmingState
import com.example.protocol.NexendCommands
import com.example.repository.DroneSystemState
import com.example.ui.theme.AviationAmber
import com.example.ui.theme.AviationGreen
import com.example.ui.theme.AviationRed
import com.example.ui.theme.NexendCardSurface
import com.example.ui.theme.NexendCyanPrimary
import kotlinx.coroutines.delay

private class PendingAction(val title: String, val message: String, val action: () -> Unit)

/**
 * Alat Kabel & Konfigurator: kumpulan fitur setup, kalibrasi, tes, backup, dan monitor live
 * yang dipakai ketika drone/remote tersambung lewat kabel USB.
 * Fitur bertanda "perintah FC" mengirim paket MSG_COMMAND_REQ dan membutuhkan firmware FC
 * yang membalas ACK; fitur monitor/backup bekerja langsung dari data yang sudah masuk.
 */
@Composable
fun ToolsCenterSheet(
    state: DroneSystemState,
    onSendCommand: (cmd: Byte, args: ByteArray, label: String, requireDisarmed: Boolean) -> Unit,
    onShowToast: (String) -> Unit,
    onClose: () -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var confirm by remember { mutableStateOf<PendingAction?>(null) }

    val cableOk = state.isSimulationMode || state.deviceStatus.remoteReady
    val fcOk = state.isSimulationMode || state.fcStatus.isConnected
    val armed = state.fcStatus.armingState == ArmingState.ARMED

    fun cmd(c: Byte, label: String, args: ByteArray = ByteArray(0), requireDisarmed: Boolean = true) {
        onSendCommand(c, args, label, requireDisarmed)
    }

    var cells by remember { mutableStateOf(state.battery.cellCount.coerceIn(1, 6)) }
    var lowCellV by remember { mutableStateOf(3.4f) }

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xF00F141C)) {
        Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = "Alat",
                        tint = NexendCyanPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("ALAT KABEL & KONFIGURATOR", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("26 fitur setup, tes, backup, dan monitor", color = Color(0xFF90A4AE), fontSize = 12.sp)
                    }
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                }
            }
            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // ---- Status koneksi ----
                item {
                    ToolCard("Status Koneksi Kabel", "Fitur perintah aktif bila kabel dan FC tersambung") {
                        StatusRow("Kabel USB / remote", if (cableOk) "TERHUBUNG" else "TIDAK TERHUBUNG", cableOk)
                        StatusRow("Flight Controller", if (fcOk) "MENJAWAB" else "TIDAK MENJAWAB", fcOk)
                        StatusRow("Status arm", if (armed) "ARMED (perintah berisiko dikunci)" else "DISARMED", !armed)
                        if (state.isSimulationMode) {
                            Text("Mode simulasi aktif: perintah dianggap berhasil tanpa mengirim ke drone.", color = AviationAmber, fontSize = 11.sp)
                        }
                    }
                }

                // ---- A. Kalibrasi (fitur 1-4) ----
                item { SectionTitle("A. KALIBRASI  (perintah FC)") }
                item {
                    ToolCard("1-2. Kalibrasi Akselerometer & Gyro", "Letakkan drone rata dan diam saat kalibrasi") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Btn("Akselerometer", fcOk, modifier = Modifier.weight(1f)) {
                                cmd(NexendCommands.CAL_ACCEL, "Kalibrasi akselerometer")
                            }
                            Btn("Gyro", fcOk, modifier = Modifier.weight(1f)) {
                                cmd(NexendCommands.CAL_GYRO, "Kalibrasi gyro")
                            }
                        }
                    }
                }
                item {
                    ToolCard("3-4. Level Horizon & Kompas", "Level: drone di permukaan rata. Kompas: putar drone ke semua arah") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Btn("Level horizon", fcOk, modifier = Modifier.weight(1f)) {
                                cmd(NexendCommands.CAL_LEVEL, "Kalibrasi level horizon")
                            }
                            Btn("Kompas", fcOk, modifier = Modifier.weight(1f)) {
                                cmd(NexendCommands.CAL_MAG, "Kalibrasi kompas")
                            }
                        }
                    }
                }

                // ---- B. Tes & keselamatan (fitur 5-8) ----
                item { SectionTitle("B. TES & KESELAMATAN  (perintah FC)") }
                item {
                    ToolCard("5. Tes Motor", "Cek arah putar tiap motor. LEPAS SEMUA BALING-BALING dulu.") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (n in 1..4) {
                                Btn("M$n", fcOk, modifier = Modifier.weight(1f)) {
                                    confirm = PendingAction(
                                        "Tes Motor $n",
                                        "Pastikan SEMUA baling-baling sudah dilepas dan drone ditahan. Motor $n akan berputar pelan."
                                    ) {
                                        cmd(NexendCommands.MOTOR_TEST, "Tes motor $n", byteArrayOf(n.toByte(), 5))
                                    }
                                }
                            }
                        }
                    }
                }
                item {
                    ToolCard("6. Stop Motor Darurat", "Menghentikan semua tes motor (selalu bisa dipakai)") {
                        Btn("STOP SEMUA MOTOR", fcOk, danger = true) {
                            cmd(NexendCommands.MOTOR_STOP, "Stop motor", requireDisarmed = false)
                        }
                    }
                }
                item {
                    ToolCard("7. Buzzer Cari Drone", "Bunyikan buzzer untuk menemukan drone yang jatuh") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Btn("Nyalakan", fcOk, modifier = Modifier.weight(1f)) {
                                cmd(NexendCommands.BUZZER, "Buzzer nyala", byteArrayOf(1), requireDisarmed = false)
                            }
                            Btn("Matikan", fcOk, modifier = Modifier.weight(1f)) {
                                cmd(NexendCommands.BUZZER, "Buzzer mati", byteArrayOf(0), requireDisarmed = false)
                            }
                        }
                    }
                }
                item {
                    ToolCard("8. Aksi Failsafe", "Yang dilakukan drone saat sinyal remote hilang") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Btn("Mendarat", fcOk, modifier = Modifier.weight(1f)) {
                                cmd(NexendCommands.SET_FAILSAFE, "Failsafe: mendarat", byteArrayOf(0))
                            }
                            Btn("RTH", fcOk, modifier = Modifier.weight(1f)) {
                                cmd(NexendCommands.SET_FAILSAFE, "Failsafe: RTH", byteArrayOf(1))
                            }
                            Btn("Diam", fcOk, modifier = Modifier.weight(1f)) {
                                cmd(NexendCommands.SET_FAILSAFE, "Failsafe: diam", byteArrayOf(2))
                            }
                        }
                    }
                }

                // ---- C. Konfigurasi FC (fitur 9-14) ----
                item { SectionTitle("C. KONFIGURASI FC  (perintah FC)") }
                item {
                    ToolCard("9. Simpan ke Memori FC", "Tulis pengaturan saat ini ke EEPROM") {
                        Btn("Simpan", fcOk) { cmd(NexendCommands.SAVE_EEPROM, "Simpan ke EEPROM") }
                    }
                }
                item {
                    ToolCard("10. Reset Pabrik", "Mengembalikan semua pengaturan FC ke bawaan") {
                        Btn("Reset pabrik", fcOk, danger = true) {
                            confirm = PendingAction("Reset Pabrik", "Semua pengaturan FC akan dihapus dan kembali ke bawaan. Lanjutkan?") {
                                cmd(NexendCommands.FACTORY_RESET, "Reset pabrik")
                            }
                        }
                    }
                }
                item {
                    ToolCard("11-12. Reboot & Mode Update Firmware", "Bootloader dipakai untuk memasang firmware baru") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Btn("Reboot FC", fcOk, modifier = Modifier.weight(1f)) {
                                cmd(NexendCommands.REBOOT, "Reboot FC")
                            }
                            Btn("Bootloader", fcOk, danger = true, modifier = Modifier.weight(1f)) {
                                confirm = PendingAction("Mode Bootloader", "FC akan masuk mode update firmware dan berhenti mengirim telemetri sampai di-reboot. Lanjutkan?") {
                                    cmd(NexendCommands.BOOTLOADER, "Masuk bootloader")
                                }
                            }
                        }
                    }
                }
                item {
                    ToolCard("13. Pengaturan Baterai", "Jumlah cell: $cells S • batas rendah ${String.format("%.1f", lowCellV)} V/cell") {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Btn("-", true) { if (cells > 1) cells -= 1 }
                            Text("$cells S", color = Color.White, fontWeight = FontWeight.Bold)
                            Btn("+", true) { if (cells < 6) cells += 1 }
                        }
                        Slider(value = lowCellV, onValueChange = { lowCellV = it }, valueRange = 3.0f..3.7f)
                        Btn("Kirim ke FC", fcOk) {
                            cmd(
                                NexendCommands.SET_BATTERY,
                                "Atur baterai ${cells}S",
                                byteArrayOf(cells.toByte(), (lowCellV * 10f).toInt().toByte())
                            )
                        }
                    }
                }
                item {
                    ToolCard("14. Set Titik Home", "Jadikan posisi GPS sekarang sebagai titik pulang (RTH)") {
                        Btn("Set home di sini", fcOk && state.gps.hasFix) {
                            cmd(NexendCommands.SET_HOME, "Set titik home")
                        }
                        if (!state.gps.hasFix) Text("Menunggu GPS fix...", color = AviationAmber, fontSize = 11.sp)
                    }
                }

                // ---- E. Monitor live (fitur 18-26) ----
                item { SectionTitle("E. MONITOR & DIAGNOSA LIVE") }
                item {
                    ToolCard("18. Grafik Attitude (Roll/Pitch/Yaw)", "Merah roll, hijau pitch, biru yaw (derajat)") {
                        RollingGraph(
                            current = listOf(state.imu.rollDeg, state.imu.pitchDeg, state.imu.yawDeg.let { if (it > 180f) it - 360f else it }),
                            colors = listOf(Color(0xFFFF5252), AviationGreen, NexendCyanPrimary),
                            range = 90f
                        )
                    }
                }
                item {
                    ToolCard("19. Grafik Gyro / Getaran", "Lonjakan acak = getaran motor atau baling-baling tidak seimbang") {
                        RollingGraph(
                            current = listOf(state.imu.gyroXDegPerSec, state.imu.gyroYDegPerSec, state.imu.gyroZDegPerSec),
                            colors = listOf(Color(0xFFFF5252), AviationGreen, NexendCyanPrimary),
                            range = 200f
                        )
                    }
                }
                item {
                    ToolCard("20. Monitor Baterai", "Tegangan, arus, dan sisa daya") {
                        val b = state.battery
                        if (!b.isValid) {
                            Text("Belum ada data baterai dari FC", color = AviationAmber, fontSize = 12.sp)
                        } else {
                            Text(
                                String.format("%.2f V • %.1f A • %d mAh terpakai", b.voltage, b.currentAmps, b.consumedMah),
                                color = Color.White, fontSize = 13.sp, fontFamily = FontFamily.Monospace
                            )
                            LinearProgressIndicator(
                                progress = { (b.remainingPercent / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                                color = if (b.isLowBattery) AviationRed else AviationGreen
                            )
                            Text("Sisa ${b.remainingPercent}% • estimasi ${b.estimatedFlightMinutes} menit", color = Color(0xFFB0BEC5), fontSize = 12.sp)
                            if (b.cellVoltages.isEmpty()) {
                                Text("Tegangan per-cell belum dikirim FC", color = Color(0xFF78909C), fontSize = 11.sp)
                            } else {
                                b.cellVoltages.forEachIndexed { i, v ->
                                    Text(String.format("Cell %d: %.2f V", i + 1, v), color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }
                item {
                    ToolCard("21. Monitor Channel RC", "Posisi stick dan saklar dari remote") {
                        val rc = state.rcTelemetry
                        RcBar("Throttle", rc.throttlePercent / 100f)
                        RcBar("Roll", (rc.rollStickPercent + 100) / 200f)
                        RcBar("Pitch", (rc.pitchStickPercent + 100) / 200f)
                        RcBar("Yaw", (rc.yawStickPercent + 100) / 200f)
                        Text(
                            "Saklar  A:${rc.switchA}  B:${rc.switchB}  C:${rc.switchC}  D:${rc.switchD}",
                            color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace
                        )
                    }
                }
                item {
                    ToolCard("22. Self-Test Sensor", "Hasil pemeriksaan semua sensor") {
                        val h = state.sensorHealth
                        SensorRow("IMU", h.imuDetected, h.imuHealthy)
                        SensorRow("Barometer", h.baroDetected, h.baroHealthy)
                        SensorRow("Kompas", h.magDetected, h.magHealthy)
                        SensorRow("GPS", h.gpsDetected, h.gpsHealthy)
                        SensorRow("ToF (jarak tanah)", h.tofDetected, h.tofHealthy)
                        SensorRow("Optical flow", h.opticalFlowDetected, h.opticalFlowHealthy)
                        Text(
                            if (h.allEssentialHealthy) "Sensor esensial (IMU & baro) SEHAT" else "Sensor esensial BERMASALAH / belum terbaca",
                            color = if (h.allEssentialHealthy) AviationGreen else AviationRed,
                            fontSize = 12.sp, fontWeight = FontWeight.Bold
                        )
                    }
                }
                item {
                    ToolCard("23. Checklist Pra-Terbang", "Semua harus hijau sebelum arm") {
                        val items = listOf(
                            "Kabel/remote tersambung" to cableOk,
                            "FC menjawab" to fcOk,
                            "Baterai ≥ 30%" to (state.battery.isValid && state.battery.remainingPercent >= 30),
                            "GPS fix, ≥ 6 satelit" to (state.gps.hasFix && state.gps.satellites >= 6),
                            "Titik home terset" to state.gps.isHomeSet,
                            "Sensor esensial sehat" to state.sensorHealth.allEssentialHealthy,
                            "IMU terkalibrasi" to state.imu.isCalibrated,
                            "Failsafe tidak aktif" to !state.fcStatus.failsafeTriggered,
                            "Drone belum ARMED" to !armed
                        )
                        items.forEach { (name, ok) -> StatusRow(name, if (ok) "OK" else "BELUM", ok) }
                        val bad = items.count { !it.second }
                        Text(
                            if (bad == 0) "SIAP TERBANG" else "BELUM SIAP ($bad masalah)",
                            color = if (bad == 0) AviationGreen else AviationRed,
                            fontSize = 13.sp, fontWeight = FontWeight.Bold
                        )
                    }
                }
                item {
                    ToolCard("24. Statistik Link & Video", "Kualitas sambungan remote dan video FPV") {
                        val rc = state.rcTelemetry
                        val v = state.videoStats
                        Text(
                            "RSSI ${rc.rssiDbm} dBm • loss ${String.format("%.1f", rc.packetLossPercent)}% • latensi ${rc.latencyMs} ms",
                            color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace
                        )
                        Text(
                            if (v.isReceiving) "Video ${v.format} ${v.resolutionWidth}x${v.resolutionHeight} ${v.fps}fps • drop ${v.droppedFrames}" else "Video belum diterima",
                            color = Color(0xFFB0BEC5), fontSize = 12.sp, fontFamily = FontFamily.Monospace
                        )
                    }
                }
                item {
                    ToolCard("25. Info Firmware & Protokol", "Versi perangkat yang terhubung") {
                        Text("FC: ${state.fcStatus.firmwareVersion}", color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        Text("Protokol: ${state.fcStatus.protocolVersion}", color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        Text("Remote: ${state.rcTelemetry.firmwareVersion}", color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        Text("Loop ${state.fcStatus.loopTimeUs} µs • CPU ${state.fcStatus.cpuLoadPercent}%", color = Color(0xFFB0BEC5), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                }
                item {
                    ToolCard("26. Salin Laporan Diagnostik", "Ringkasan lengkap untuk dikirim saat minta bantuan") {
                        Btn("Salin laporan", true) {
                            clipboard.setText(AnnotatedString(buildReport(state)))
                            onShowToast("Laporan diagnostik disalin ke clipboard")
                        }
                    }
                }
                item { Spacer(modifier = Modifier.height(24.dp)) }
            }
        }
    }

    confirm?.let { c ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(c.title) },
            text = { Text(c.message) },
            confirmButton = {
                TextButton(onClick = {
                    confirm = null
                    c.action()
                }) { Text("LANJUTKAN", color = AviationRed) }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("BATAL") } }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = NexendCyanPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun ToolCard(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NexendCardSurface)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Color(0xFF90A4AE), fontSize = 11.sp)
            content()
        }
    }
}

@Composable
private fun Btn(
    text: String,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    danger: Boolean = false,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (danger) AviationRed else Color(0xFF00838F),
            contentColor = Color.White,
            disabledContainerColor = Color(0x33FFFFFF),
            disabledContentColor = Color(0x88FFFFFF)
        )
    ) {
        Text(text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun StatusRow(label: String, value: String, ok: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(if (ok) AviationGreen else AviationRed))
            Spacer(modifier = Modifier.width(8.dp))
            Text(label, color = Color.White, fontSize = 12.sp)
        }
        Text(value, color = if (ok) AviationGreen else AviationRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SensorRow(name: String, detected: Boolean, healthy: Boolean) {
    val text = when {
        !detected -> "TIDAK TERDETEKSI"
        healthy -> "SEHAT"
        else -> "BERMASALAH"
    }
    StatusRow(name, text, detected && healthy)
}

@Composable
private fun RcBar(label: String, fraction: Float) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color(0xFFB0BEC5), fontSize = 11.sp, modifier = Modifier.width(60.dp))
        LinearProgressIndicator(
            progress = { fraction.coerceIn(0f, 1f) },
            modifier = Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = NexendCyanPrimary
        )
    }
}

/** Grafik garis bergulir (±12 detik) untuk beberapa deret data sekaligus. */
@Composable
internal fun RollingGraph(current: List<Float>, colors: List<Color>, range: Float) {
    val count = current.size
    val history = remember { List(count) { mutableStateListOf<Float>() } }
    val latest by rememberUpdatedState(current)
    LaunchedEffect(Unit) {
        while (true) {
            delay(100)
            latest.forEachIndexed { i, v ->
                if (i < history.size) {
                    history[i].add(v)
                    if (history[i].size > 120) history[i].removeAt(0)
                }
            }
        }
    }
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(110.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0x66000000))
    ) {
        val w = size.width
        val h = size.height
        drawLine(Color(0x44FFFFFF), Offset(0f, h / 2f), Offset(w, h / 2f), strokeWidth = 1.dp.toPx())
        for (s in 0 until count) {
            val pts = history[s]
            if (pts.size < 2) continue
            val path = Path()
            val stepX = w / 119f
            pts.forEachIndexed { i, v ->
                val x = i * stepX
                val y = (h / 2f - (v / range).coerceIn(-1f, 1f) * (h / 2f))
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, colors[s % colors.size], style = Stroke(width = 2.dp.toPx()))
        }
    }
}

private fun buildReport(s: DroneSystemState): String = buildString {
    appendLine("=== LAPORAN DIAGNOSTIK NEXEND FLY ===")
    appendLine("Simulasi: ${s.isSimulationMode} | Remote USB: ${s.deviceStatus.remoteReady} | FC menjawab: ${s.fcStatus.isConnected}")
    appendLine("Arm: ${s.fcStatus.armingState.label} | Mode: ${s.fcStatus.flightMode.displayName}")
    appendLine("FC: ${s.fcStatus.firmwareVersion} | Protokol: ${s.fcStatus.protocolVersion}")
    appendLine("Baterai: ${s.battery.voltage} V, ${s.battery.remainingPercent}% (valid=${s.battery.isValid})")
    appendLine("GPS: fix=${s.gps.hasFix}, sat=${s.gps.satellites}, hdop=${s.gps.hdop}")
    appendLine("IMU: roll=${s.imu.rollDeg}, pitch=${s.imu.pitchDeg}, yaw=${s.imu.yawDeg}, kalibrasi=${s.imu.isCalibrated}")
    appendLine("Sensor sehat: imu=${s.sensorHealth.imuHealthy}, baro=${s.sensorHealth.baroHealthy}, mag=${s.sensorHealth.magHealthy}, gps=${s.sensorHealth.gpsHealthy}, tof=${s.sensorHealth.tofHealthy}, flow=${s.sensorHealth.opticalFlowHealthy}")
    appendLine("RC: rssi=${s.rcTelemetry.rssiDbm} dBm, loss=${s.rcTelemetry.packetLossPercent}%")
    appendLine("Video: ${s.videoStats.isReceiving}, ${s.videoStats.resolutionWidth}x${s.videoStats.resolutionHeight} ${s.videoStats.fps}fps")
}
