package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ImuTelemetry
import com.example.model.VideoFeedStats

@Composable
fun FpvVideoView(
    isSimulation: Boolean,
    videoStats: VideoFeedStats,
    imuTelemetry: ImuTelemetry,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0D11))
    ) {
        if (isSimulation) {
            // Simulated FPV landscape & artificial horizon
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val cx = w / 2f
                val cy = h / 2f

                // Atmospheric Sky and Ground Gradient
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF0F2027),
                            Color(0xFF203A43),
                            Color(0xFF2C5364)
                        ),
                        startY = 0f,
                        endY = cy
                    ),
                    topLeft = Offset.Zero,
                    size = androidx.compose.ui.geometry.Size(w, cy)
                )

                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF1E272C),
                            Color(0xFF12181B)
                        ),
                        startY = cy,
                        endY = h
                    ),
                    topLeft = Offset(0f, cy),
                    size = androidx.compose.ui.geometry.Size(w, h - cy)
                )

                // Mountain silhouettes in background
                val mountainPath = Path().apply {
                    moveTo(0f, cy + 20f)
                    lineTo(w * 0.15f, cy - 60f)
                    lineTo(w * 0.35f, cy + 10f)
                    lineTo(w * 0.55f, cy - 80f)
                    lineTo(w * 0.75f, cy - 20f)
                    lineTo(w * 0.90f, cy - 50f)
                    lineTo(w, cy + 15f)
                    lineTo(w, h)
                    lineTo(0f, h)
                    close()
                }
                drawPath(
                    path = mountainPath,
                    color = Color(0x6618222A)
                )

                // Artificial Horizon with Pitch & Roll rotation
                rotate(
                    degrees = -imuTelemetry.rollDeg,
                    pivot = Offset(cx, cy)
                ) {
                    val pitchOffset = (imuTelemetry.pitchDeg * 4.0f).coerceIn(-150f, 150f)

                    // Horizon line
                    drawLine(
                        color = Color(0x8000E5FF),
                        start = Offset(cx - 220f, cy + pitchOffset),
                        end = Offset(cx + 220f, cy + pitchOffset),
                        strokeWidth = 1.5f
                    )

                    // Pitch ladder rungs (+10, -10 deg)
                    val rungs = listOf(-10f, 10f)
                    for (deg in rungs) {
                        val rungY = cy + pitchOffset - (deg * 4.0f)
                        drawLine(
                            color = Color(0x6000E5FF),
                            start = Offset(cx - 60f, rungY),
                            end = Offset(cx + 60f, rungY),
                            strokeWidth = 1.5f
                        )
                    }
                }

                // Center Aircraft Crosshair
                val crosshairColor = Color(0xE6FFFFFF)
                val stroke = Stroke(width = 2.0f, cap = StrokeCap.Round)

                // Left wing
                drawLine(
                    color = crosshairColor,
                    start = Offset(cx - 45f, cy),
                    end = Offset(cx - 15f, cy),
                    strokeWidth = 2.5f
                )
                drawLine(
                    color = crosshairColor,
                    start = Offset(cx - 15f, cy),
                    end = Offset(cx - 15f, cy + 8f),
                    strokeWidth = 2.5f
                )

                // Right wing
                drawLine(
                    color = crosshairColor,
                    start = Offset(cx + 15f, cy),
                    end = Offset(cx + 45f, cy),
                    strokeWidth = 2.5f
                )
                drawLine(
                    color = crosshairColor,
                    start = Offset(cx + 15f, cy),
                    end = Offset(cx + 15f, cy + 8f),
                    strokeWidth = 2.5f
                )

                // Center pip
                drawCircle(
                    color = crosshairColor,
                    radius = 2.5f,
                    center = Offset(cx, cy)
                )
            }
        } else {
            // Hardware Mode without video stream: sleek dark camera surface
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width / 2f
                val cy = size.height / 2f

                // Subtle grid
                val gridColor = Color(0x0DFFFFFF)
                drawLine(gridColor, Offset(cx, 0f), Offset(cx, size.height), 1f)
                drawLine(gridColor, Offset(0f, cy), Offset(size.width, cy), 1f)
            }

            // No signal overlay
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "NEXEND FPV • TIDAK ADA SINYAL VIDEO ROTG",
                    color = Color(0x40FFFFFF),
                    fontSize = 14.sp,
                    letterSpacing = 2.sp
                )
            }
        }

        // Live Feed Watermark & Statistics tag (top center or subtle)
        if (isSimulation || videoStats.isReceiving) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 8.dp)
            ) {
                Text(
                    text = if (isSimulation) "[SIMULASI FPV] 720x576 @ 60 FPS • ROTG02" else "${videoStats.format} • ${videoStats.resolutionWidth}x${videoStats.resolutionHeight} @ ${videoStats.fps}fps",
                    color = Color(0x60FFFFFF),
                    fontSize = 11.sp
                )
            }
        }
    }
}
