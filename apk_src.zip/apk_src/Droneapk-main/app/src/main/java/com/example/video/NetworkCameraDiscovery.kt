package com.example.video

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Discovers IP cameras that advertise standard RTSP/HTTP services over mDNS/NSD. */
class NetworkCameraDiscovery(context: Context) {
    private val appContext = context.applicationContext
    private val manager = appContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val multicastLock = (appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
        .createMulticastLock("NexendFlyCameraDiscovery").apply { setReferenceCounted(false) }
    private val _devices = MutableStateFlow<List<String>>(emptyList())
    val devices: StateFlow<List<String>> = _devices.asStateFlow()
    private val listeners = mutableListOf<NsdManager.DiscoveryListener>()
    private val lock = Any()

    fun start() {
        try { if (!multicastLock.isHeld) multicastLock.acquire() } catch (_: Exception) { }
        listOf("_rtsp._tcp.", "_http._tcp.", "_https._tcp.", "_mjpeg._tcp.").forEach { type ->
            val listener = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(serviceType: String) = Unit
                override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                    try { manager.stopServiceDiscovery(this) } catch (_: Exception) { }
                }
                override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) = Unit
                override fun onDiscoveryStopped(serviceType: String) = Unit
                override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                    val prefix = "${serviceInfo.serviceName} · "
                    _devices.value = _devices.value.filterNot { it.startsWith(prefix) }
                }
                override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                    if (serviceInfo.serviceType.contains("rtsp") || serviceInfo.serviceType.contains("http") || serviceInfo.serviceType.contains("mjpeg")) {
                        try {
                            manager.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                                override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) = Unit
                                override fun onServiceResolved(info: NsdServiceInfo) {
                                    val host = try { java.net.InetAddress.getByName(info.hostName).hostAddress ?: return } catch (_: Exception) { return }
                                    val scheme = when { info.serviceType.contains("rtsp") -> "rtsp"; info.serviceType.contains("https") -> "https"; else -> "http" }
                                    val entry = "${info.serviceName} · $host:${info.port} ($scheme)"
                                    _devices.value = (_devices.value.filterNot { it.substringBefore(" · ") == info.serviceName } + entry).distinct().take(20)
                                }
                            })
                        } catch (_: Exception) { }
                    }
                }
            }
            synchronized(lock) { listeners.add(listener) }
            try { manager.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, listener) } catch (_: Exception) { }
        }
    }

    fun stop() {
        synchronized(lock) {
            listeners.forEach { try { manager.stopServiceDiscovery(it) } catch (_: Exception) { } }
            listeners.clear()
            try { if (multicastLock.isHeld) multicastLock.release() } catch (_: Exception) { }
        }
    }
}
