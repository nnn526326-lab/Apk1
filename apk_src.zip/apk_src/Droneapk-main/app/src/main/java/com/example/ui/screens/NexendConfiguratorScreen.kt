package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ArmingState
import com.example.protocol.NexendCommands
import com.example.repository.DroneSystemState
import com.example.ui.sheets.RollingGraph
import com.example.ui.theme.AviationAmber
import com.example.ui.theme.AviationGreen
import com.example.ui.theme.AviationRed
import com.example.ui.theme.NexendCardSurface
import com.example.ui.theme.NexendCyanPrimary
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlinx.coroutines.delay

private enum class AltSource(val label: String) { BARO("BARO"), TOF("ToF"), AUTO("AUTO") }
private enum class HeadingSource(val label: String) { IMU("IMU"), MAG("KOMPAS") }

/** Pengaturan tampilan & input pengguna di Configurator (semua state satu tempat). */
private class CfgState {
    var altSource by mutableStateOf(AltSource.AUTO)
    var headingSource by mutableStateOf(HeadingSource.IMU)
    var followGps by mutableStateOf(false)
    var showGrid by mutableStateOf(true)
    var showAxes by mutableStateOf(false)
    var spinProps by mutableStateOf(true)
    var orbitYaw by mutableStateOf(0f)
    var orbitPitch by mutableStateOf(24f)
    var zoom by mutableStateOf(1f)
    var trimRoll by mutableStateOf(0f)
    var trimPitch by mutableStateOf(0f)
    var align by mutableStateOf(0)
    var filterHz by mutableStateOf(100f)
    var telemRate by mutableStateOf(25)
    var recording by mutableStateOf(false)
    val rec = mutableStateListOf<String>()
}

private class CfgConfirm(val title: String, val message: String, val action: () -> Unit)

private class Derived(
    val roll: Float,
    val pitch: Float,
    val heading: Float,
    val altitudeM: Float,
    val altLabel: String,
    val posX: Float,
    val posZ: Float
)

private fun derive(s: DroneSystemState, cfg: CfgState): Derived {
    val baroOk = s.baro.isValid
    val tofOk = s.tof.isValid && !s.tof.isOutOfRange
    val baroM = if (baroOk) s.baro.altitudeMeters else 0f
    val tofM = if (tofOk) s.tof.distanceCm / 100f else 0f
    val useTof = when (cfg.altSource) {
        AltSource.TOF -> true
        AltSource.BARO -> false
        AltSource.AUTO -> tofOk && tofM < 3.5f
    }
    val alt = if (useTof) tofM else baroM
    val label = if (useTof) "ToF" else "BARO"

    val mag = s.magHeadingDeg
    val rawHeading = if (cfg.headingSource == HeadingSource.MAG && mag != null) mag else s.imu.yawDeg
    val heading = ((rawHeading % 360f) + 360f) % 360f

    var px = 0f
    var pz = 0f
    if (cfg.followGps && s.gps.isHomeSet && s.gps.hasFix) {
        val dx = ((s.gps.longitude - s.gps.homeLongitude) * 111320.0 * cos(Math.toRadians(s.gps.latitude))).toFloat()
        val dz = ((s.gps.latitude - s.gps.homeLatitude) * 110540.0).toFloat()
        px = (dx * 0.1f).coerceIn(-3f, 3f)
        pz = (dz * 0.1f).coerceIn(-3f, 3f)
    }
    return Derived(s.imu.rollDeg, s.imu.pitchDeg, heading, alt, label, px, pz)
}

/**
 * NEXEND CONFIGURATOR (gaya iNAV). Tidak punya tombol masuk: layar ini dibuka otomatis hanya
 * ketika drone tersambung ke aplikasi lewat kabel USB, dan menutup sendiri saat kabel dicabut.
 */
@Composable
fun NexendConfiguratorScreen(
    state: DroneSystemState,
    onSendCommand: (cmd: Byte, args: ByteArray, label: String, requireDisarmed: Boolean) -> Unit,
    onShowToast: (String) -> Unit
) {
    val cfg = remember { CfgState() }
    val clipboard = LocalClipboardManager.current
    var confirm by remember { mutableStateOf<CfgConfirm?>(null) }
    val d = derive(state, cfg)
    val armed = state.fcStatus.armingState == ArmingState.ARMED
    val fcOk = state.isSimulationMode || state.fcStatus.isConnected

    fun cmd(c: Byte, label: String, args: ByteArray = ByteArray(0), requireDisarmed: Boolean = true) {
        onSendCommand(c, args, label, requireDisarmed)
    }

    // Rekam sesi sensor (10 sampel/detik, maks 60 detik)
    val latest by rememberUpdatedState(d)
    val latestState by rememberUpdatedState(state)
    LaunchedEffect(cfg.recording) {
        if (cfg.recording) {
            cfg.rec.clear()
            cfg.rec.add("t_ms,roll,pitch,heading,alt_m,gx,gy,gz")
            var t = 0
            while (cfg.rec.size < 601) {
                delay(100)
                t += 100
                val x = latest
                val st = latestState
                cfg.rec.add(
                    "$t,${x.roll},${x.pitch},${x.heading},${x.altitudeM}," +
                        "${st.imu.gyroXDegPerSec},${st.imu.gyroYDegPerSec},${st.imu.gyroZDegPerSec}"
                )
            }
            cfg.recording = false
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080C11))
    ) {
        Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
            // ---- Bilah atas ----
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F1620))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("NEXEND CONFIGURATOR", color = NexendCyanPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("Drone tersambung lewat kabel USB", color = Color(0xFF90A4AE), fontSize = 10.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Dot("KABEL", true)
                    Dot("FC", fcOk)
                    Dot(if (armed) "ARMED" else "DISARMED", !armed)
                    if (state.isSimulationMode) Text("SIM", color = AviationAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val wide = maxWidth > 700.dp
                if (wide) {
                    Row(modifier = Modifier.fillMaxSize()) {
                        Column(
                            modifier = Modifier.width(290.dp).fillMaxHeight().verticalScroll(rememberScrollState()).padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) { ViewPanel(cfg); SensorPanel(state, d) }
                        Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                            Model3D(state, cfg, d, armed, Modifier.fillMaxSize())
                        }
                        Column(
                            modifier = Modifier.width(290.dp).fillMaxHeight().verticalScroll(rememberScrollState()).padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) { ImuPanel(cfg, fcOk, ::cmd, { confirm = it }, clipboard::setText, onShowToast) }
                    }
                } else {
                    Column(
                        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(modifier = Modifier.fillMaxWidth().height(300.dp)) {
                            Model3D(state, cfg, d, armed, Modifier.fillMaxSize())
                        }
                        ViewPanel(cfg)
                        SensorPanel(state, d)
                        ImuPanel(cfg, fcOk, ::cmd, { confirm = it }, clipboard::setText, onShowToast)
                    }
                }
            }
        }
    }

    confirm?.let { c ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(c.title) },
            text = { Text(c.message) },
            confirmButton = {
                TextButton(onClick = { confirm = null; c.action() }) { Text("LANJUTKAN", color = AviationRed) }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("BATAL") } }
        )
    }
}

// ============================ Model 3D ============================

@Composable
private fun Model3D(state: DroneSystemState, cfg: CfgState, d: Derived, armed: Boolean, modifier: Modifier) {
    Box(modifier = modifier) {
        Drone3DView(
            rollDeg = d.roll,
            pitchDeg = d.pitch,
            headingDeg = d.heading,
            altUnits = (d.altitudeM * 0.35f).coerceIn(0f, 3.2f),
            posX = d.posX,
            posZ = d.posZ,
            spinSpeed = if (cfg.spinProps && armed) 1500f else 0f,
            showGrid = cfg.showGrid,
            showAxes = cfg.showAxes,
            orbitYaw = cfg.orbitYaw,
            orbitPitch = cfg.orbitPitch,
            zoom = cfg.zoom,
            onOrbit = { dx, dy ->
                cfg.orbitYaw += dx * 0.4f
                cfg.orbitPitch = (cfg.orbitPitch - dy * 0.3f).coerceIn(5f, 85f)
            },
            modifier = Modifier.fillMaxSize()
        )
        Column(modifier = Modifier.align(Alignment.TopStart).padding(10.dp)) {
            Text(
                String.format("R %.1f°  P %.1f°  H %.0f°", d.roll, d.pitch, d.heading),
                color = Color.White, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold
            )
            Text(
                String.format("ALT %.2f m (%s)", d.altitudeM, d.altLabel),
                color = NexendCyanPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace
            )
            if (!state.imu.isValid) {
                Text("Menunggu data IMU dari FC...", color = AviationAmber, fontSize = 11.sp)
            }
        }
        Text(
            "Geser untuk memutar pandangan",
            color = Color(0x88FFFFFF), fontSize = 10.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(6.dp)
        )
    }
}

private data class V3(val x: Float, val y: Float, val z: Float)

private const val RAD = 0.017453292f

private fun rotX(v: V3, deg: Float): V3 {
    val a = deg * RAD; val c = cos(a); val s = sin(a)
    return V3(v.x, v.y * c - v.z * s, v.y * s + v.z * c)
}

private fun rotY(v: V3, deg: Float): V3 {
    val a = deg * RAD; val c = cos(a); val s = sin(a)
    return V3(v.x * c + v.z * s, v.y, -v.x * s + v.z * c)
}

private fun rotZ(v: V3, deg: Float): V3 {
    val a = deg * RAD; val c = cos(a); val s = sin(a)
    return V3(v.x * c - v.y * s, v.x * s + v.y * c, v.z)
}

@Composable
private fun Drone3DView(
    rollDeg: Float,
    pitchDeg: Float,
    headingDeg: Float,
    altUnits: Float,
    posX: Float,
    posZ: Float,
    spinSpeed: Float,
    showGrid: Boolean,
    showAxes: Boolean,
    orbitYaw: Float,
    orbitPitch: Float,
    zoom: Float,
    onOrbit: (Float, Float) -> Unit,
    modifier: Modifier
) {
    var spin by remember { mutableStateOf(0f) }
    val speed by rememberUpdatedState(spinSpeed)
    val orbit by rememberUpdatedState(onOrbit)
    LaunchedEffect(Unit) {
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = (now - last) / 1.0e9f
            last = now
            spin = (spin + speed * dt) % 360f
        }
    }

    Canvas(
        modifier = modifier.pointerInput(Unit) {
            detectDragGestures { _, drag -> orbit(drag.x, drag.y) }
        }
    ) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h * 0.55f
        val unit = minOf(w, h) * 0.20f * zoom
        val camDist = 7f

        fun view(v: V3): V3 = rotX(rotY(v, orbitYaw), -orbitPitch)
        fun proj(v: V3): Offset {
            val z = (v.z + camDist).coerceAtLeast(0.5f)
            val k = camDist / z
            return Offset(cx + v.x * unit * k, cy - v.y * unit * k)
        }
        fun body(v: V3): V3 {
            val a = rotZ(v, -rollDeg)
            val b = rotX(a, -pitchDeg)
            val c = rotY(b, headingDeg)
            return V3(c.x + posX, c.y + altUnits, c.z + posZ)
        }
        fun bw(v: V3): V3 = view(body(v))

        // --- Tanah: grid dan bayangan ---
        if (showGrid) {
            for (i in -3..3) {
                val a1 = proj(view(V3(i.toFloat(), 0f, -3f))); val b1 = proj(view(V3(i.toFloat(), 0f, 3f)))
                drawLine(Color(0x2800E5FF), a1, b1, strokeWidth = 1.dp.toPx())
                val a2 = proj(view(V3(-3f, 0f, i.toFloat()))); val b2 = proj(view(V3(3f, 0f, i.toFloat())))
                drawLine(Color(0x2800E5FF), a2, b2, strokeWidth = 1.dp.toPx())
            }
        }
        val shadowR = 0.9f / (1f + altUnits * 0.6f)
        val shadow = Path()
        for (i in 0..23) {
            val t = i * 15f * RAD
            val o = proj(view(V3(posX + shadowR * cos(t), 0f, posZ + shadowR * sin(t))))
            if (i == 0) shadow.moveTo(o.x, o.y) else shadow.lineTo(o.x, o.y)
        }
        shadow.close()
        drawPath(shadow, Color(0x66000000))
        if (altUnits > 0.05f) {
            drawLine(
                Color(0x5500E5FF),
                proj(view(V3(posX, 0f, posZ))),
                proj(view(V3(posX, altUnits, posZ))),
                strokeWidth = 1.dp.toPx()
            )
        }

        // --- Drone: kumpulkan primitif lalu urutkan dari yang terjauh ---
        val prims = ArrayList<Pair<Float, () -> Unit>>()

        fun line(a: V3, b: V3, color: Color, widthDp: Float) {
            val ca = bw(a); val cb = bw(b)
            prims.add(((ca.z + cb.z) / 2f) to {
                drawLine(color, proj(ca), proj(cb), strokeWidth = widthDp.dp.toPx(), cap = StrokeCap.Round)
            })
        }

        fun poly(pts: List<V3>, fill: Color, stroke: Color?) {
            val cam = pts.map { bw(it) }
            val depth = cam.map { it.z }.average().toFloat()
            prims.add(depth to {
                val p = Path()
                cam.forEachIndexed { i, v ->
                    val o = proj(v)
                    if (i == 0) p.moveTo(o.x, o.y) else p.lineTo(o.x, o.y)
                }
                p.close()
                drawPath(p, fill)
                if (stroke != null) drawPath(p, stroke, style = Stroke(width = 1.2.dp.toPx()))
            })
        }

        // Badan (kotak pipih)
        val hx = 0.36f; val hy = 0.07f; val hz = 0.46f
        fun c(sx: Float, sy: Float, sz: Float) = V3(sx * hx, sy * hy, sz * hz)
        val edge = Color(0xCC00E5FF)
        poly(listOf(c(-1f, 1f, -1f), c(1f, 1f, -1f), c(1f, 1f, 1f), c(-1f, 1f, 1f)), Color(0xFF2B3A44), edge)
        poly(listOf(c(-1f, -1f, -1f), c(1f, -1f, -1f), c(1f, -1f, 1f), c(-1f, -1f, 1f)), Color(0xFF10161B), edge)
        poly(listOf(c(-1f, -1f, 1f), c(1f, -1f, 1f), c(1f, 1f, 1f), c(-1f, 1f, 1f)), Color(0xFF3A4B57), edge)
        poly(listOf(c(-1f, -1f, -1f), c(1f, -1f, -1f), c(1f, 1f, -1f), c(-1f, 1f, -1f)), Color(0xFF34444F), edge)
        poly(listOf(c(-1f, -1f, -1f), c(-1f, -1f, 1f), c(-1f, 1f, 1f), c(-1f, 1f, -1f)), Color(0xFF30404B), edge)
        poly(listOf(c(1f, -1f, -1f), c(1f, -1f, 1f), c(1f, 1f, 1f), c(1f, 1f, -1f)), Color(0xFF30404B), edge)
        // Baterai di bawah
        val bx = 0.2f; val bz = 0.36f
        poly(listOf(V3(-bx, -0.07f, -bz), V3(bx, -0.07f, -bz), V3(bx, -0.07f, bz), V3(-bx, -0.07f, bz)), Color(0xFF5D4300), null)
        poly(listOf(V3(-bx, -0.2f, -bz), V3(bx, -0.2f, -bz), V3(bx, -0.2f, bz), V3(-bx, -0.2f, bz)), Color(0xFFB07C00), Color(0xFFFFB300))
        poly(listOf(V3(-bx, -0.2f, bz), V3(bx, -0.2f, bz), V3(bx, -0.07f, bz), V3(-bx, -0.07f, bz)), Color(0xFF8D6500), Color(0xFFFFB300))
        // Panah hidung (depan)
        poly(listOf(V3(-0.16f, 0.09f, 0.46f), V3(0.16f, 0.09f, 0.46f), V3(0f, 0.09f, 1.0f)), Color(0xFFE53935), null)

        // Lengan + motor + baling-baling
        val motors = listOf(
            V3(1f, 0f, 1f) to 1f, V3(-1f, 0f, 1f) to -1f,
            V3(1f, 0f, -1f) to -1f, V3(-1f, 0f, -1f) to 1f
        )
        motors.forEachIndexed { idx, (pos, dir) ->
            val front = idx < 2
            line(V3(0f, 0f, 0f), pos, Color(0xFFB0BEC5), 5f)
            val r = 0.55f
            val ringTop = pos.y + 0.12f
            val ring = (0..15).map { i ->
                val t = i * 22.5f * RAD
                V3(pos.x + r * cos(t), ringTop, pos.z + r * sin(t))
            }
            poly(ring, if (front) Color(0x33E53935) else Color(0x3300E5FF), if (front) Color(0xFFE53935) else Color(0xFF00E5FF))
            val a = spin * dir * RAD
            for (k in 0..1) {
                val ang = a + k * 3.1415927f / 2f
                line(
                    V3(pos.x - r * cos(ang), ringTop, pos.z - r * sin(ang)),
                    V3(pos.x + r * cos(ang), ringTop, pos.z + r * sin(ang)),
                    Color(0xFFECEFF1), 2.5f
                )
            }
            line(pos, V3(pos.x, ringTop, pos.z), Color(0xFF78909C), 6f)
        }

        if (showAxes) {
            line(V3(0f, 0f, 0f), V3(1.3f, 0f, 0f), Color(0xFFFF5252), 2f)
            line(V3(0f, 0f, 0f), V3(0f, 1.3f, 0f), Color(0xFF69F0AE), 2f)
            line(V3(0f, 0f, 0f), V3(0f, 0f, 1.3f), Color(0xFF448AFF), 2f)
        }

        prims.sortedByDescending { it.first }.forEach { it.second() }
    }
}

// ============================ Panel UI ============================

@Composable
private fun Dot(label: String, ok: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(if (ok) AviationGreen else AviationRed))
        Spacer(modifier = Modifier.width(5.dp))
        Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Panel(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(NexendCardSurface)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, color = NexendCyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        content()
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) Color(0x5500E5FF) else Color(0x22FFFFFF))
            .border(1.dp, if (selected) NexendCyanPrimary else Color(0x33FFFFFF), RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(text, color = Color.White, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Text(label, color = Color(0xFFB0BEC5), fontSize = 11.sp)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun Act(text: String, enabled: Boolean, modifier: Modifier = Modifier, danger: Boolean = false, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (danger) AviationRed else Color(0xFF00838F),
            contentColor = Color.White,
            disabledContainerColor = Color(0x33FFFFFF),
            disabledContentColor = Color(0x88FFFFFF)
        )
    ) { Text(text, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun Mono(text: String, color: Color = Color.White) {
    Text(text, color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
}

@Composable
private fun HealthChip(name: String, detected: Boolean, healthy: Boolean) {
    val c = when {
        !detected -> Color(0xFF607D8B)
        healthy -> AviationGreen
        else -> AviationRed
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, c, RoundedCornerShape(10.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) { Text(name, color = c, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
}

/** Panel kiri atas: pilihan tampilan 3D (fitur 1-9). */
@Composable
private fun ViewPanel(cfg: CfgState) {
    Panel("TAMPILAN 3D") {
        Text("1. Sumber ketinggian", color = Color(0xFFB0BEC5), fontSize = 11.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AltSource.values().forEach { Chip(it.label, cfg.altSource == it) { cfg.altSource = it } }
        }
        Text("2. Sumber heading", color = Color(0xFFB0BEC5), fontSize = 11.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HeadingSource.values().forEach { Chip(it.label, cfg.headingSource == it) { cfg.headingSource = it } }
        }
        SwitchRow("3. Ikuti posisi GPS", cfg.followGps) { cfg.followGps = it }
        SwitchRow("4. Grid & bayangan tanah", cfg.showGrid) { cfg.showGrid = it }
        SwitchRow("5. Sumbu XYZ", cfg.showAxes) { cfg.showAxes = it }
        SwitchRow("6. Baling-baling berputar saat ARMED", cfg.spinProps) { cfg.spinProps = it }
        SliderRow("7. Zoom", cfg.zoom, 0.6f..1.8f) { cfg.zoom = it }
        Text("8. Sudut pandang", color = Color(0xFFB0BEC5), fontSize = 11.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("Belakang", false) { cfg.orbitYaw = 0f; cfg.orbitPitch = 24f }
            Chip("Atas", false) { cfg.orbitYaw = 0f; cfg.orbitPitch = 85f }
            Chip("Samping", false) { cfg.orbitYaw = 90f; cfg.orbitPitch = 12f }
        }
        Act("9. Reset pandangan & zoom", true, Modifier.fillMaxWidth()) {
            cfg.orbitYaw = 0f; cfg.orbitPitch = 24f; cfg.zoom = 1f
        }
    }
}

/** Panel kiri bawah: pembacaan sensor live (fitur 10-19). */
@Composable
private fun SensorPanel(s: DroneSystemState, d: Derived) {
    Panel("10. ATTITUDE DIGITAL") {
        Mono(String.format("Roll    %7.1f°", d.roll))
        Mono(String.format("Pitch   %7.1f°", d.pitch))
        Mono(String.format("Heading %7.1f°", d.heading))
    }
    Panel("11-12. HORIZON & KOMPAS") {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Horizon(d.roll, d.pitch)
            Compass(d.heading)
        }
    }
    Panel("13. ALTIMETER (BARO vs ToF vs GPS)") {
        AltBar("Baro", if (s.baro.isValid) s.baro.altitudeMeters else null)
        AltBar("ToF", if (s.tof.isValid && !s.tof.isOutOfRange) s.tof.distanceCm / 100f else null)
        AltBar("GPS", if (s.gps.hasFix) s.gps.altitudeMeters else null)
    }
    Panel("14. GPS") {
        Mono("Fix  : ${s.gps.fixType}  Sat: ${s.gps.satellites}  HDOP: ${s.gps.hdop}")
        Mono(String.format("Lat  : %.6f", s.gps.latitude))
        Mono(String.format("Lon  : %.6f", s.gps.longitude))
        Mono(String.format("Jarak ke home: %.1f m", s.gps.distanceToHomeMeters))
    }
    Panel("15. GRAFIK GYRO (°/dtk)") {
        RollingGraph(
            current = listOf(s.imu.gyroXDegPerSec, s.imu.gyroYDegPerSec, s.imu.gyroZDegPerSec),
            colors = listOf(Color(0xFFFF5252), AviationGreen, NexendCyanPrimary),
            range = 200f
        )
    }
    Panel("16. AKSELEROMETER & GETARAN") {
        val g = sqrt(s.imu.accelXG * s.imu.accelXG + s.imu.accelYG * s.imu.accelYG + s.imu.accelZG * s.imu.accelZG)
        Mono(String.format("|a| = %.2f g  (diam ≈ 1.00 g)", g))
        val dev = abs(g - 1f)
        LinearProgressIndicator(
            progress = { (dev / 0.5f).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = if (dev > 0.25f) AviationRed else AviationGreen
        )
        Mono(if (dev > 0.25f) "Getaran / gerakan tinggi" else "Stabil", if (dev > 0.25f) AviationAmber else AviationGreen)
    }
    Panel("17. KESEHATAN SENSOR") {
        val h = s.sensorHealth
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HealthChip("IMU", h.imuDetected, h.imuHealthy)
            HealthChip("BARO", h.baroDetected, h.baroHealthy)
            HealthChip("MAG", h.magDetected, h.magHealthy)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HealthChip("GPS", h.gpsDetected, h.gpsHealthy)
            HealthChip("ToF", h.tofDetected, h.tofHealthy)
            HealthChip("FLOW", h.opticalFlowDetected, h.opticalFlowHealthy)
        }
    }
    Panel("18. BAROMETER") {
        Mono(String.format("Tekanan : %.1f hPa", s.baro.pressureHpa))
        Mono(String.format("Suhu    : %.1f °C", s.baro.temperatureCelsius))
        Mono(String.format("V-speed : %.2f m/s", s.baro.verticalSpeedMs))
    }
    Panel("19. ToF & OPTICAL FLOW") {
        Mono(if (s.tof.isValid) "ToF: ${s.tof.distanceCm} cm" else if (s.tof.isOutOfRange) "ToF: di luar jangkauan" else "ToF: tidak ada data")
        Mono(String.format("Flow: x %.1f  y %.1f  kualitas %d", s.opticalFlow.motionX, s.opticalFlow.motionY, s.opticalFlow.surfaceQuality))
    }
}

@Composable
private fun AltBar(label: String, meters: Float?) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color(0xFFB0BEC5), fontSize = 11.sp, modifier = Modifier.width(42.dp))
        LinearProgressIndicator(
            progress = { ((meters ?: 0f) / 10f).coerceIn(0f, 1f) },
            modifier = Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = if (meters == null) Color(0xFF607D8B) else NexendCyanPrimary
        )
        Spacer(modifier = Modifier.width(8.dp))
        Mono(if (meters == null) "--" else String.format("%.2f m", meters))
    }
}

@Composable
private fun Horizon(roll: Float, pitch: Float) {
    Canvas(modifier = Modifier.size(100.dp)) {
        val r = size.minDimension / 2f
        val c = center
        val clip = Path().apply { addOval(Rect(c.x - r, c.y - r, c.x + r, c.y + r)) }
        clipPath(clip) {
            rotate(degrees = -roll, pivot = c) {
                val off = (pitch / 45f) * r
                drawRect(Color(0xFF1E88E5), topLeft = Offset(c.x - 2 * r, c.y - 2 * r + off), size = Size(4 * r, 2 * r))
                drawRect(Color(0xFF6D4C41), topLeft = Offset(c.x - 2 * r, c.y + off), size = Size(4 * r, 2 * r))
                drawLine(Color.White, Offset(c.x - 2 * r, c.y + off), Offset(c.x + 2 * r, c.y + off), strokeWidth = 2.dp.toPx())
            }
        }
        drawCircle(Color.White, radius = r, center = c, style = Stroke(width = 2.dp.toPx()))
        drawLine(Color(0xFFFFB300), Offset(c.x - r * 0.5f, c.y), Offset(c.x + r * 0.5f, c.y), strokeWidth = 3.dp.toPx())
    }
}

@Composable
private fun Compass(heading: Float) {
    Box(modifier = Modifier.size(100.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(100.dp)) {
            val r = size.minDimension / 2f
            val c = center
            drawCircle(Color(0x33FFFFFF), radius = r, center = c, style = Stroke(width = 2.dp.toPx()))
            rotate(degrees = -heading, pivot = c) {
                for (i in 0 until 12) {
                    val a = i * 30f * RAD
                    val len = if (i == 0) 0.28f else 0.14f
                    val col = if (i == 0) AviationRed else Color(0xAAFFFFFF)
                    drawLine(
                        col,
                        Offset(c.x + sin(a) * r * (1f - len), c.y - cos(a) * r * (1f - len)),
                        Offset(c.x + sin(a) * r, c.y - cos(a) * r),
                        strokeWidth = (if (i == 0) 3f else 1.5f).dp.toPx()
                    )
                }
            }
            drawLine(NexendCyanPrimary, Offset(c.x, c.y - r), Offset(c.x, c.y - r * 0.7f), strokeWidth = 3.dp.toPx())
        }
        Text(String.format("%.0f°", heading), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

/** Panel kanan: ubah IMU, kalibrasi, dan simpan (fitur 20-29). */
@Composable
private fun ImuPanel(
    cfg: CfgState,
    fcOk: Boolean,
    cmd: (Byte, String, ByteArray, Boolean) -> Unit,
    askConfirm: (CfgConfirm) -> Unit,
    copyText: (AnnotatedString) -> Unit,
    toast: (String) -> Unit
) {
    Panel("KALIBRASI SENSOR  (perintah FC)") {
        Act("20. Kalibrasi akselerometer", fcOk, Modifier.fillMaxWidth()) {
            cmd(NexendCommands.CAL_ACCEL, "Kalibrasi akselerometer", ByteArray(0), true)
        }
        Act("21. Kalibrasi gyro", fcOk, Modifier.fillMaxWidth()) {
            cmd(NexendCommands.CAL_GYRO, "Kalibrasi gyro", ByteArray(0), true)
        }
        Act("22. Kalibrasi kompas", fcOk, Modifier.fillMaxWidth()) {
            cmd(NexendCommands.CAL_MAG, "Kalibrasi kompas", ByteArray(0), true)
        }
    }
    Panel("UBAH IMU  (perintah FC)") {
        SliderRow(String.format("23. Trim roll: %.1f°", cfg.trimRoll), cfg.trimRoll, -5f..5f) { cfg.trimRoll = (it * 10f).toInt() / 10f }
        SliderRow(String.format("24. Trim pitch: %.1f°", cfg.trimPitch), cfg.trimPitch, -5f..5f) { cfg.trimPitch = (it * 10f).toInt() / 10f }
        Act("Kirim trim ke FC", fcOk, Modifier.fillMaxWidth()) {
            cmd(
                NexendCommands.SET_TRIM, "Trim IMU",
                byteArrayOf((cfg.trimRoll * 10f).toInt().toByte(), (cfg.trimPitch * 10f).toInt().toByte()), true
            )
        }
        Text("25. Orientasi board IMU", color = Color(0xFFB0BEC5), fontSize = 11.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (i in 0..3) Chip("${i * 90}°", cfg.align == i) { cfg.align = i }
        }
        Act("Kirim orientasi ke FC", fcOk, Modifier.fillMaxWidth()) {
            askConfirm(CfgConfirm("Orientasi board", "Ubah orientasi IMU menjadi ${cfg.align * 90}°? Salah orientasi membuat drone tidak stabil.") {
                cmd(NexendCommands.SET_ALIGN, "Orientasi IMU ${cfg.align * 90}°", byteArrayOf(cfg.align.toByte()), true)
            })
        }
        SliderRow(String.format("26. Filter gyro LPF: %d Hz", cfg.filterHz.toInt()), cfg.filterHz, 20f..200f) { cfg.filterHz = it }
        Act("Kirim filter ke FC", fcOk, Modifier.fillMaxWidth()) {
            cmd(NexendCommands.SET_GYRO_FILTER, "Filter gyro ${cfg.filterHz.toInt()} Hz", byteArrayOf(cfg.filterHz.toInt().toByte()), true)
        }
        Text("27. Laju telemetri", color = Color(0xFFB0BEC5), fontSize = 11.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(10, 25, 50).forEach { Chip("$it Hz", cfg.telemRate == it) { cfg.telemRate = it } }
        }
        Act("Kirim laju telemetri", fcOk, Modifier.fillMaxWidth()) {
            cmd(NexendCommands.SET_TELEM_RATE, "Telemetri ${cfg.telemRate} Hz", byteArrayOf(cfg.telemRate.toByte()), false)
        }
    }
    Panel("SIMPAN & DATA") {
        Act("28. Simpan ke memori FC", fcOk, Modifier.fillMaxWidth()) {
            cmd(NexendCommands.SAVE_EEPROM, "Simpan ke EEPROM", ByteArray(0), true)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Act(if (cfg.recording) "Stop rekam" else "29. Rekam sensor", true, Modifier.weight(1f), danger = cfg.recording) {
                cfg.recording = !cfg.recording
            }
            Act("Salin CSV", cfg.rec.size > 1, Modifier.weight(1f)) {
                copyText(AnnotatedString(cfg.rec.joinToString("\n")))
                toast("${cfg.rec.size - 1} sampel disalin ke clipboard")
            }
        }
        Mono(if (cfg.recording) "Merekam... ${cfg.rec.size - 1} sampel" else "Rekaman: ${maxOf(cfg.rec.size - 1, 0)} sampel", Color(0xFF90A4AE))
        Text(
            "Perintah ke FC butuh firmware yang membalas ACK. Perintah berisiko ditolak saat ARMED.",
            color = Color(0xFF78909C), fontSize = 10.sp
        )
    }
}
