package com.example.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AviationRed

@Composable
fun SafetyArmingDialog(
    isArmed: Boolean,
    isSimulation: Boolean,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    isLandRequest: Boolean = false
) {
    val titleText = when {
        isLandRequest -> "KONFIRMASI LANDING TERKENDALI"
        isArmed -> "KONFIRMASI DISARM"
        else -> "PERINGATAN KESELAMATAN: TAKE-OFF / ARM"
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = titleText,
                color = if (isArmed || isLandRequest) Color.White else AviationRed,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column {
                when {
                    isLandRequest -> Text(
                        "Drone akan melakukan pendaratan terkendali (LAND). Motor tidak diputus langsung; FC menurunkan ketinggian secara bertahap hingga mendarat. Pastikan area di bawah aman.",
                        color = Color.LightGray
                    )
                    isArmed -> Text(
                        "Apakah Anda yakin ingin DISARM? Jika di udara, gunakan LAND untuk pendaratan terkendali. DISARM mematikan motor segera.",
                        color = Color.LightGray
                    )
                    else -> Text(
                        if (isSimulation)
                            "Mode Simulasi: Motor virtual akan diaktifkan untuk simulasi penerbangan."
                        else
                            "PERHATIAN! TAKE-OFF / ARM akan memutar baling-baling. Pastikan area sekitar aman (radius 5 m), baterai kokoh, dan status READY TO FLY.",
                        color = Color.LightGray
                    )
                }
                if (!isSimulation) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Status FC dan remote harus cocok dengan protokol NEXEND. Perintah gagal akan ditampilkan dari respons FC.",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isArmed && !isLandRequest) MaterialTheme.colorScheme.primary else AviationRed
                )
            ) {
                Text(when {
                    isLandRequest -> "Mulai LAND"
                    isArmed -> "Lanjutkan Disarm"
                    else -> "Saya Mengerti & TAKE-OFF"
                })
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
