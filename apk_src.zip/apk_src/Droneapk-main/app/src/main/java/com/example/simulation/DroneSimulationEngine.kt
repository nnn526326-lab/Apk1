package com.example.simulation

import com.example.model.ArmingState
import com.example.model.BaroTelemetry
import com.example.model.BatteryTelemetry
import com.example.model.FcStatus
import com.example.model.FlightMode
import com.example.model.GpsTelemetry
import com.example.model.ImuTelemetry
import com.example.model.OpticalFlowTelemetry
import com.example.model.RcTelemetry
import com.example.model.SensorHealth
import com.example.model.ToFTelemetry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

data class SimulationState(
    val fcStatus: FcStatus = FcStatus(),
    val rcTelemetry: RcTelemetry = RcTelemetry(),
    val battery: BatteryTelemetry = BatteryTelemetry(),
    val gps: GpsTelemetry = GpsTelemetry(),
    val imu: ImuTelemetry = ImuTelemetry(),
    val baro: BaroTelemetry = BaroTelemetry(),
    val tof: ToFTelemetry = ToFTelemetry(),
    val opticalFlow: OpticalFlowTelemetry = OpticalFlowTelemetry(),
    val sensorHealth: SensorHealth = SensorHealth()
)

class DroneSimulationEngine(
    private val scope: CoroutineScope
) {
    private val _simState = MutableStateFlow(SimulationState())
    val simState: StateFlow<SimulationState> = _simState.asStateFlow()

    private var simJob: Job? = null
    private var isRunning = false

    // Simulation parameters
    private var tickCount = 0L
    private var currentAlt = 0.0f
    private var currentVSpeed = 0.0f
    private var currentHSpeed = 0.0f
    private var batteryPercent = 98
    private var batteryVoltage = 16.5f // 4S battery
    private var isSimArmed = false
    private var currentMode = FlightMode.POS_HOLD

    fun start() {
        if (isRunning) return
        isRunning = true
        simJob = scope.launch(Dispatchers.Default) {
            val homeLat = -7.250445
            val homeLon = 112.768845

            while (isActive && isRunning) {
                delay(50) // 20Hz telemetry update
                tickCount++

                val timeSec = tickCount * 0.05f

                // Smooth simulated flight oscillations (drone hover & gentle drift)
                val rollOsc = (sin(timeSec * 0.8) * 3.5).toFloat()
                val pitchOsc = (cos(timeSec * 0.6) * 2.8).toFloat()
                val yawOsc = ((timeSec * 4.0) % 360).toFloat()

                if (isSimArmed) {
                    if (currentAlt < 24.5f) {
                        currentAlt += 0.35f
                        currentVSpeed = 0.8f
                    } else {
                        currentAlt = 25.0f + (sin(timeSec * 0.5) * 0.4).toFloat()
                        currentVSpeed = (sin(timeSec * 0.5) * 0.2).toFloat()
                    }
                    currentHSpeed = 4.2f + (sin(timeSec * 0.3) * 0.8).toFloat()

                    // Slow discharge
                    if (tickCount % 400 == 0L && batteryPercent > 10) {
                        batteryPercent--
                        batteryVoltage = 14.8f + (batteryPercent / 100f) * 2.0f
                    }
                } else {
                    currentAlt = 0.0f
                    currentVSpeed = 0.0f
                    currentHSpeed = 0.0f
                }

                val simulatedDist = if (isSimArmed) (timeSec * 2.5f) % 250f else 0.0f
                val currentLat = homeLat + (simulatedDist * 0.0000089)
                val currentLon = homeLon + (simulatedDist * 0.0000089)

                _simState.value = SimulationState(
                    fcStatus = FcStatus(
                        isConnected = true,
                        armingState = if (isSimArmed) ArmingState.ARMED else ArmingState.DISARMED,
                        flightMode = if (isSimArmed) currentMode else FlightMode.STABILIZE,
                        failsafeTriggered = false,
                        loopTimeUs = 250,
                        cpuLoadPercent = 22,
                        firmwareVersion = "NEXEND-FC-RP2040 [SIM v2.1]",
                        protocolVersion = "NX-PROTO 1.4",
                        flightTimeSeconds = if (isSimArmed) (timeSec).toLong() else 0L,
                        horizontalSpeedMs = currentHSpeed,
                        lastUpdateMs = System.currentTimeMillis()
                    ),
                    rcTelemetry = RcTelemetry(
                        isConnected = true,
                        throttlePercent = if (isSimArmed) 52 else 0,
                        rollStickPercent = (sin(timeSec) * 20).toInt(),
                        pitchStickPercent = (cos(timeSec) * 15).toInt(),
                        yawStickPercent = 0,
                        switchA = if (isSimArmed) 100 else 0, // Arm
                        switchB = 50, // Mode
                        switchC = 0, // RTH
                        switchD = 0,
                        rssiDbm = -65,
                        packetLossPercent = 0.1f,
                        latencyMs = 12,
                        heartbeatIntervalMs = 20,
                        firmwareVersion = "ESP32-C3-RC [SIM v1.0]",
                        lastUpdateMs = System.currentTimeMillis()
                    ),
                    battery = BatteryTelemetry(
                        voltage = batteryVoltage,
                        currentAmps = if (isSimArmed) 14.2f else 0.8f,
                        remainingPercent = batteryPercent,
                        consumedMah = if (isSimArmed) (tickCount * 0.2f).toInt() else 15,
                        cellCount = 4,
                        cellVoltages = listOf(
                            batteryVoltage / 4f,
                            batteryVoltage / 4f,
                            batteryVoltage / 4f,
                            batteryVoltage / 4f
                        ),
                        isLowBattery = batteryPercent < 20,
                        isCriticalBattery = batteryPercent < 10,
                        isValid = true,
                        lastUpdateMs = System.currentTimeMillis()
                    ),
                    gps = GpsTelemetry(
                        hasFix = true,
                        fixType = "3D FIX",
                        satellites = 18,
                        latitude = currentLat,
                        longitude = currentLon,
                        altitudeMeters = currentAlt,
                        hdop = 0.8f,
                        distanceToHomeMeters = simulatedDist,
                        homeLatitude = homeLat,
                        homeLongitude = homeLon,
                        isHomeSet = true,
                        isValid = true,
                        lastUpdateMs = System.currentTimeMillis()
                    ),
                    imu = ImuTelemetry(
                        rollDeg = rollOsc,
                        pitchDeg = pitchOsc,
                        yawDeg = yawOsc,
                        gyroXDegPerSec = (cos(timeSec * 0.8) * 4f).toFloat(),
                        gyroYDegPerSec = (sin(timeSec * 0.6) * 3f).toFloat(),
                        gyroZDegPerSec = 0.5f,
                        accelXG = 0.02f,
                        accelYG = 0.01f,
                        accelZG = 0.99f,
                        isCalibrated = true,
                        isValid = true,
                        lastUpdateMs = System.currentTimeMillis()
                    ),
                    baro = BaroTelemetry(
                        altitudeMeters = currentAlt,
                        verticalSpeedMs = currentVSpeed,
                        pressureHpa = (1013.25f - (currentAlt * 0.12f)),
                        temperatureCelsius = 28.5f,
                        isValid = true,
                        lastUpdateMs = System.currentTimeMillis()
                    ),
                    tof = ToFTelemetry(
                        distanceCm = (currentAlt * 100).toInt().coerceAtMost(400),
                        isValid = currentAlt < 4.0f,
                        isOutOfRange = currentAlt >= 4.0f,
                        lastUpdateMs = System.currentTimeMillis()
                    ),
                    opticalFlow = OpticalFlowTelemetry(
                        motionX = 0.1f,
                        motionY = -0.1f,
                        surfaceQuality = 85,
                        isValid = currentAlt < 3.0f
                    ),
                    sensorHealth = SensorHealth(
                        imuDetected = true,
                        imuHealthy = true,
                        baroDetected = true,
                        baroHealthy = true,
                        magDetected = true,
                        magHealthy = true,
                        gpsDetected = true,
                        gpsHealthy = true,
                        tofDetected = true,
                        tofHealthy = true,
                        opticalFlowDetected = true,
                        opticalFlowHealthy = true
                    )
                )
            }
        }
    }

    fun toggleArm() {
        isSimArmed = !isSimArmed
    }

    fun stop() {
        isRunning = false
        simJob?.cancel()
    }
}
