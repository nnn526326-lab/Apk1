package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AviationAmberBg
import com.example.ui.theme.AviationGreenBg
import com.example.ui.theme.AviationRedBg

enum class BannerType {
    ERROR,
    WARNING,
    SUCCESS,
    INFO
}

@Composable
fun TopBarAlertBanner(
    text: String,
    type: BannerType = BannerType.ERROR,
    onClick: () -> Unit = {},
    modifier: Modifier = Modifier,
    scroll: Boolean = true
) {
    val bgColor = when (type) {
        BannerType.ERROR -> Color(0xE6E53935)
        BannerType.WARNING -> Color(0xE6FB8C00)
        BannerType.SUCCESS -> Color(0xE643A047)
        BannerType.INFO -> Color(0xE60288D1)
    }

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .clipToBounds(),
        contentAlignment = Alignment.CenterStart
    ) {
        if (scroll && text.length > 28) {
            val infiniteTransition = rememberInfiniteTransition(label = "marquee")
            val offset by infiniteTransition.animateFloat(
                initialValue = 1f,
                targetValue = -1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 8000 + text.length * 40, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "offset"
            )
            Text(
                text = text + "   •   " + text,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                modifier = Modifier.offset(x = (offset * 120).dp)
            )
        } else {
            Text(
                text = text,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1
            )
        }
    }
}
