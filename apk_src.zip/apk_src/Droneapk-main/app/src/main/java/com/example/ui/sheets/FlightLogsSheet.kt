package com.example.ui.sheets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FlightLogEntry
import com.example.model.LogSeverity
import com.example.ui.theme.AviationAmber
import com.example.ui.theme.AviationGreen
import com.example.ui.theme.AviationRed
import com.example.ui.theme.NexendCardSurface
import com.example.ui.theme.NexendCyanPrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FlightLogsSheet(
    logs: List<FlightLogEntry>,
    onClearLogs: () -> Unit,
    onExportLogs: () -> String,
    onClose: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedSeverity by remember { mutableStateOf<LogSeverity?>(null) }
    val timeFormat = remember { SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()) }

    val filteredLogs = logs.filter { entry ->
        val matchesSeverity = selectedSeverity == null || entry.severity == selectedSeverity
        val matchesSearch = searchQuery.isBlank() ||
                entry.message.contains(searchQuery, ignoreCase = true) ||
                entry.category.contains(searchQuery, ignoreCase = true)
        matchesSeverity && matchesSearch
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xF00F141C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Description,
                        contentDescription = "Logs",
                        tint = NexendCyanPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "LOG PENERBANGAN & DIAGNOSTIK",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${logs.size} peristiwa dicatat secara lokal",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                }
                Row {
                    OutlinedButton(onClick = onClearLogs) {
                        Icon(Icons.Default.ClearAll, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Bersihkan")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Filter row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = selectedSeverity == null,
                    onClick = { selectedSeverity = null },
                    label = { Text("SEMUA") }
                )
                FilterChip(
                    selected = selectedSeverity == LogSeverity.INFO,
                    onClick = { selectedSeverity = if (selectedSeverity == LogSeverity.INFO) null else LogSeverity.INFO },
                    label = { Text("INFO") }
                )
                FilterChip(
                    selected = selectedSeverity == LogSeverity.WARN,
                    onClick = { selectedSeverity = if (selectedSeverity == LogSeverity.WARN) null else LogSeverity.WARN },
                    label = { Text("WARN") }
                )
                FilterChip(
                    selected = selectedSeverity == LogSeverity.ERROR,
                    onClick = { selectedSeverity = if (selectedSeverity == LogSeverity.ERROR) null else LogSeverity.ERROR },
                    label = { Text("ERROR") }
                )
                FilterChip(
                    selected = selectedSeverity == LogSeverity.CRITICAL,
                    onClick = { selectedSeverity = if (selectedSeverity == LogSeverity.CRITICAL) null else LogSeverity.CRITICAL },
                    label = { Text("CRITICAL") }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Log entries
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(filteredLogs) { entry ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = NexendCardSurface),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = timeFormat.format(Date(entry.timestampMs)),
                                color = Color.Gray,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "[${entry.severity}]",
                                color = when (entry.severity) {
                                    LogSeverity.INFO -> Color(0xFF03A9F4)
                                    LogSeverity.WARN -> AviationAmber
                                    LogSeverity.ERROR -> AviationRed
                                    LogSeverity.CRITICAL -> Color(0xFFFF1744)
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "<${entry.category}>",
                                color = NexendCyanPrimary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = entry.message,
                                color = Color.White,
                                fontSize = 12.sp,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}
