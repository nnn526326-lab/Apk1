package com.example.ui.sheets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.protocol.NexendCommands
import com.example.ui.theme.AviationAmber
import com.example.ui.theme.NexendCardSurface
import com.example.ui.theme.NexendCyanPrimary

@Composable
fun SettingsSheet(
    onClose: () -> Unit,
    isSimulation: Boolean = false,
    simulatedCable: Boolean = false,
    onToggleSimulation: (Boolean) -> Unit = {},
    onToggleSimulatedCable: (Boolean) -> Unit = {},
    rthMaxAltM: Int? = null,
    canSendToFc: Boolean = false,
    isArmed: Boolean = false,
    onSetRthMaxAlt: (Int) -> Unit = {},
    onReadRthMaxAlt: () -> Unit = {}
) {
    // Nilai yang sedang diedit di layar. Nilai yang BENAR-BENAR dipakai FC hanya "rthMaxAltM" (read-back dari FC).
    var editAlt by remember { mutableStateOf(rthMaxAltM ?: 60) }
    LaunchedEffect(rthMaxAltM) { if (rthMaxAltM != null) editAlt = rthMaxAltM }
    val altMin = NexendCommands.RTH_ALT_MIN_M
    val altMax = NexendCommands.RTH_ALT_MAX_M
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xF00F141C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = NexendCyanPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "PENGATURAN SISTEM (SETTINGS)",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Mode Operasi, Satuan Ukuran, dan Batas Keamanan",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Mode simulasi untuk uji tanpa drone
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NexendCardSurface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("MODE SIMULASI (UJI TANPA DRONE)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Simulasi sensor & remote", color = Color.LightGray, fontSize = 12.sp)
                            Switch(checked = isSimulation, onCheckedChange = onToggleSimulation)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Simulasi drone via kabel (Configurator)", color = Color.LightGray, fontSize = 12.sp)
                            Switch(checked = simulatedCable, onCheckedChange = onToggleSimulatedCable)
                        }
                    }
                }

                // Ketinggian RTH maksimal -> dikirim ke FC (via remote), nilai tampil = konfirmasi FC
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NexendCardSurface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("KETINGGIAN MAKSIMAL RTH", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Batas atas ketinggian saat Return-to-Home. FC tidak akan naik melebihi nilai ini. Hanya bisa diubah saat DISARM.",
                            color = Color.Gray, fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(onClick = { editAlt = (editAlt - 5).coerceIn(altMin, altMax) }) { Text("-5") }
                            Text("$editAlt m", color = NexendCyanPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            OutlinedButton(onClick = { editAlt = (editAlt + 5).coerceIn(altMin, altMax) }) { Text("+5") }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        RowText("Tersimpan di FC", if (rthMaxAltM != null) "$rthMaxAltM m (dikonfirmasi FC)" else "belum dibaca dari FC")
                        if (isArmed) Text("Drone ARMED: pengaturan terkunci.", color = AviationAmber, fontSize = 11.sp)
                        else if (!canSendToFc) Text("FC belum terhubung lewat remote.", color = AviationAmber, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onSetRthMaxAlt(editAlt) },
                                enabled = canSendToFc && !isArmed,
                                modifier = Modifier.weight(1f)
                            ) { Text("KIRIM KE FC") }
                            OutlinedButton(
                                onClick = onReadRthMaxAlt,
                                enabled = canSendToFc,
                                modifier = Modifier.weight(1f)
                            ) { Text("BACA DARI FC") }
                        }
                    }
                }

                // Safety Limits
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NexendCardSurface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("BATAS KEAMANAN PENERBANGAN (SAFETY LIMITS)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        RowText("Ketinggian Maksimal (info, tidak dikirim ke FC)", "120 meter")
                        RowText("Jarak Maksimal (info, tidak dikirim ke FC)", "1000 meter")
                        RowText("Ambang RTH Baterai Rendah (info, diatur di FC)", "-")
                        RowText("Failsafe Action (info, diatur di FC)", "-")
                    }
                }

                // App Info Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NexendCardSurface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("TENTANG NEXEND FLY", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        RowText("Aplikasi", "NEXEND FLY Companion by NDL")
                        RowText("Versi Aplikasi", "v2.5.0 Production")
                        RowText("Arsitektur", "Native Kotlin / Jetpack Compose USB Host")
                        RowText("Penerima Video", "ROTG01 / ROTG02 UVC Receiver Support")
                        RowText("Flight Controller", "Raspberry Pi Pico RP2040 Dual-Core")
                        RowText("Remote Link", "RP2040 (Remote + FC) via USB OTG")
                    }
                }
            }
        }
    }
}

@Composable
private fun RowText(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = Color.LightGray, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
