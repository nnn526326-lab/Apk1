package com.example.protocol

class NexendPacketParser(
    private val onPacketReceived: (NexendPacket) -> Unit,
    private val onError: (String) -> Unit = {}
) {
    private enum class State {
        WAIT_SYNC_1,
        WAIT_SYNC_2,
        WAIT_MSG_ID,
        WAIT_SEQ,
        WAIT_LEN,
        READ_PAYLOAD,
        WAIT_CRC_1,
        WAIT_CRC_2
    }

    private var currentState = State.WAIT_SYNC_1
    private var currentMsgId: Byte = 0
    private var currentSeq: Int = 0
    private var currentLen: Int = 0
    private var payloadBuffer = ByteArray(256)
    private var payloadBytesRead = 0
    private var crcHigh: Int = 0
    private var lastSequence: Int = -1

    var totalPacketsReceived: Long = 0
        private set
    var totalChecksumErrors: Long = 0
        private set
    var totalSequenceGaps: Long = 0
        private set

    fun reset() {
        currentState = State.WAIT_SYNC_1
        payloadBytesRead = 0
        lastSequence = -1
    }

    fun parseBytes(data: ByteArray, length: Int = data.size) {
        for (i in 0 until length) {
            val b = data[i]
            when (currentState) {
                State.WAIT_SYNC_1 -> {
                    if (b == NexendProtocol.SYNC_1) {
                        currentState = State.WAIT_SYNC_2
                    }
                }
                State.WAIT_SYNC_2 -> {
                    if (b == NexendProtocol.SYNC_2) {
                        currentState = State.WAIT_MSG_ID
                    } else if (b != NexendProtocol.SYNC_1) {
                        currentState = State.WAIT_SYNC_1
                    }
                }
                State.WAIT_MSG_ID -> {
                    currentMsgId = b
                    currentState = State.WAIT_SEQ
                }
                State.WAIT_SEQ -> {
                    currentSeq = b.toInt() and 0xFF
                    currentState = State.WAIT_LEN
                }
                State.WAIT_LEN -> {
                    currentLen = b.toInt() and 0xFF
                    payloadBytesRead = 0
                    if (currentLen == 0) {
                        currentState = State.WAIT_CRC_1
                    } else {
                        currentState = State.READ_PAYLOAD
                    }
                }
                State.READ_PAYLOAD -> {
                    payloadBuffer[payloadBytesRead++] = b
                    if (payloadBytesRead >= currentLen) {
                        currentState = State.WAIT_CRC_1
                    }
                }
                State.WAIT_CRC_1 -> {
                    crcHigh = b.toInt() and 0xFF
                    currentState = State.WAIT_CRC_2
                }
                State.WAIT_CRC_2 -> {
                    val crcLow = b.toInt() and 0xFF
                    val expectedCrc = (crcHigh shl 8) or crcLow

                    // Verify CRC
                    val verifyBuffer = ByteArray(3 + currentLen)
                    verifyBuffer[0] = currentMsgId
                    verifyBuffer[1] = currentSeq.toByte()
                    verifyBuffer[2] = currentLen.toByte()
                    System.arraycopy(payloadBuffer, 0, verifyBuffer, 3, currentLen)

                    val computedCrc = NexendProtocol.calculateCrc16(verifyBuffer)
                    if (computedCrc == expectedCrc) {
                        // Check sequence gap
                        if (lastSequence != -1) {
                            val expectedSeq = (lastSequence + 1) and 0xFF
                            if (currentSeq != expectedSeq) {
                                totalSequenceGaps++
                            }
                        }
                        lastSequence = currentSeq
                        totalPacketsReceived++

                        val payloadCopy = ByteArray(currentLen)
                        System.arraycopy(payloadBuffer, 0, payloadCopy, 0, currentLen)
                        onPacketReceived(NexendPacket(currentMsgId, currentSeq, payloadCopy))
                    } else {
                        totalChecksumErrors++
                        onError("CRC mismatch: computed=0x${Integer.toHexString(computedCrc)}, expected=0x${Integer.toHexString(expectedCrc)}")
                    }
                    currentState = State.WAIT_SYNC_1
                }
            }
        }
    }
}
