package com.example.usb

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import com.example.model.NexendDeviceType
import com.example.model.UsbDeviceItem

object UsbDeviceDetector {

    // Known Vendor IDs
    private const val VID_RASPBERRY_PI = 0x2E8A
    private const val VID_ESPRESSIF = 0x303A
    private const val VID_WCH = 0x1A86     // CH340 / CH341 serial converter
    private const val VID_SILABS = 0x10C4  // CP2102 / CP2104 serial converter
    private const val VID_FTDI = 0x0403

    // Known UVC Video Vendor IDs common in ROTG FPV receivers
    private val ROTG_KNOWN_VIDS = setOf(0x0C45, 0x18EC, 0x1B3B, 0x534D, 0x1908, 0x04F2)

    fun identifyDevice(device: UsbDevice, hasPermission: Boolean): UsbDeviceItem {
        val detectedType = classifyDevice(device)
        val interfacesDesc = buildString {
            for (i in 0 until device.interfaceCount) {
                val iface = device.getInterface(i)
                append("IF#$i(Cls:0x${Integer.toHexString(iface.interfaceClass)}, Eps:${iface.endpointCount}) ")
            }
        }.trim()

        return UsbDeviceItem(
            deviceId = device.deviceId,
            deviceName = device.deviceName,
            vendorId = device.vendorId,
            productId = device.productId,
            manufacturerName = try { device.manufacturerName } catch (e: Exception) { "Unknown" },
            productName = try { device.productName } catch (e: Exception) { "USB Device" },
            detectedType = detectedType,
            interfaceCount = device.interfaceCount,
            interfacesDescription = interfacesDesc,
            hasPermission = hasPermission,
            isConnected = true
        )
    }

    private fun classifyDevice(device: UsbDevice): NexendDeviceType {
        // 1. Check for UVC (USB Video Class: 0x0E = 14)
        for (i in 0 until device.interfaceCount) {
            val iface = device.getInterface(i)
            if (iface.interfaceClass == 14 || iface.interfaceClass == UsbConstants.USB_CLASS_VIDEO) {
                return NexendDeviceType.ROTG_VIDEO_RECEIVER
            }
        }

        if (device.vendorId in ROTG_KNOWN_VIDS) {
            return NexendDeviceType.ROTG_VIDEO_RECEIVER
        }

        // 2. RP2040 = remote sekaligus jalur ke FC.
        //    Mode BOOTSEL (flash) muncul sebagai Mass Storage -> bukan remote.
        if (device.vendorId == VID_RASPBERRY_PI) {
            var onlyMassStorage = device.interfaceCount > 0
            for (i in 0 until device.interfaceCount) {
                if (device.getInterface(i).interfaceClass != UsbConstants.USB_CLASS_MASS_STORAGE) {
                    onlyMassStorage = false
                }
            }
            return if (onlyMassStorage) NexendDeviceType.GENERIC_USB_DEVICE else NexendDeviceType.RP2040_FC
        }

        // 3. Check for ESP32-C3 Remote Controller
        if (device.vendorId == VID_ESPRESSIF) {
            return NexendDeviceType.ESP32_C3_RC
        }

        // 4. Check for typical USB Serial interfaces used on Pico or ESP32 boards
        var hasCdcData = false
        var hasComm = false
        for (i in 0 until device.interfaceCount) {
            val iface = device.getInterface(i)
            if (iface.interfaceClass == UsbConstants.USB_CLASS_COMM) hasComm = true
            if (iface.interfaceClass == UsbConstants.USB_CLASS_CDC_DATA) hasCdcData = true
        }

        if (hasComm || hasCdcData || device.vendorId == VID_WCH || device.vendorId == VID_SILABS || device.vendorId == VID_FTDI) {
            // Assign as generic or remote based on vendor
            return if (device.vendorId == VID_WCH || device.vendorId == VID_SILABS) {
                NexendDeviceType.ESP32_C3_RC
            } else {
                NexendDeviceType.GENERIC_USB_DEVICE
            }
        }

        return NexendDeviceType.UNKNOWN
    }
}
