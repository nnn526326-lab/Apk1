package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.FlightLogEntry
import com.example.repository.DroneRepository
import com.example.repository.DroneSystemState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

enum class ActiveSheet {
    NONE,
    DEVICE_CENTER,
    REMOTE_CENTER,
    FC_CENTER,
    SENSOR_CENTER,
    DIAGNOSTICS,
    SETTINGS,
    CONNECTION_GUIDE,
    TOOLS_CENTER
}

enum class ActiveScreen {
    HOME_DASHBOARD,
    LIVE_VIEW_HUD,
    CONFIGURATOR
}

class DroneViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = DroneRepository(application.applicationContext)

    val systemState: StateFlow<DroneSystemState> = repository.systemState
    val logs: StateFlow<List<FlightLogEntry>> = repository.diagnosticsLogger.logsFlow

    private val _currentScreen = MutableStateFlow(ActiveScreen.HOME_DASHBOARD)
    val currentScreen: StateFlow<ActiveScreen> = _currentScreen.asStateFlow()

    private val _activeSheet = MutableStateFlow(ActiveSheet.NONE)
    val activeSheet: StateFlow<ActiveSheet> = _activeSheet.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private enum class AutoTarget { NONE, CAMERA, CONFIGURATOR }

    init {
        // Perpindahan layar otomatis (hanya pada "tepi" perubahan, bukan terus-menerus):
        //  - Drone tersambung KABEL langsung  => masuk Nexend Configurator (dari layar mana pun)
        //  - Remote tersambung                => masuk tampilan kamera (hanya dari Home)
        //  - Kabel dicabut saat di Configurator => kembali ke Home
        viewModelScope.launch {
            repository.systemState
                .map {
                    when {
                        it.canOpenConfigurator -> AutoTarget.CONFIGURATOR
                        it.canOpenCameraView -> AutoTarget.CAMERA
                        else -> AutoTarget.NONE
                    }
                }
                .distinctUntilChanged()
                .collect { target ->
                    when (target) {
                        AutoTarget.CONFIGURATOR -> {
                            _activeSheet.value = ActiveSheet.NONE
                            _currentScreen.value = ActiveScreen.CONFIGURATOR
                        }
                        AutoTarget.CAMERA -> {
                            if (_currentScreen.value == ActiveScreen.HOME_DASHBOARD ||
                                _currentScreen.value == ActiveScreen.CONFIGURATOR
                            ) {
                                _activeSheet.value = ActiveSheet.NONE
                                _currentScreen.value = ActiveScreen.LIVE_VIEW_HUD
                            }
                        }
                        AutoTarget.NONE -> {
                            if (_currentScreen.value == ActiveScreen.CONFIGURATOR) {
                                _activeSheet.value = ActiveSheet.NONE
                                _currentScreen.value = ActiveScreen.HOME_DASHBOARD
                            }
                        }
                    }
                }
        }
    }

    fun navigateTo(screen: ActiveScreen) {
        // Tampilan kamera hanya bisa dibuka bila remote terhubung (atau mode simulasi)
        if (screen == ActiveScreen.LIVE_VIEW_HUD && !repository.systemState.value.canOpenCameraView) {
            showToast("Hubungkan remote (RP2040) lewat OTG terlebih dahulu")
            return
        }
        // Configurator tidak bisa dibuka manual: hanya otomatis saat drone tersambung lewat kabel
        if (screen == ActiveScreen.CONFIGURATOR && !repository.systemState.value.canOpenConfigurator) {
            return
        }
        _currentScreen.value = screen
    }

    fun openSheet(sheet: ActiveSheet) {
        _activeSheet.value = sheet
    }

    fun closeSheet() {
        _activeSheet.value = ActiveSheet.NONE
    }

    fun toggleSimulationMode(enabled: Boolean) {
        repository.setSimulationMode(enabled)
    }

    fun toggleSimulatedCable(enabled: Boolean) {
        repository.setSimulatedCable(enabled)
    }

    fun toggleSimulatedArm() {
        repository.toggleSimulatedArm()
    }

    fun requestArm() = repository.requestArm { _, msg -> _toastMessage.value = msg }
    fun requestRth() = repository.requestRth { _, msg -> _toastMessage.value = msg }
    fun requestLand() = repository.requestLand { _, msg -> _toastMessage.value = msg }

    fun onUsbIntent() {
        repository.refreshUsbDevices()
    }

    fun refreshUsbDevices() {
        repository.refreshUsbDevices()
    }

    fun requestUsbPermission(deviceId: Int) {
        repository.requestUsbPermission(deviceId)
    }

    fun sendCommand(
        cmd: Byte,
        args: ByteArray = ByteArray(0),
        label: String,
        requireDisarmed: Boolean = true,
        onResult: (Boolean, String) -> Unit
    ) {
        repository.sendCommand(cmd, args, label, requireDisarmed) { ok, msg ->
            // Callback datang dari thread background; kirim hasil ke UI lewat toast flow
            _toastMessage.value = msg
            onResult(ok, msg)
        }
    }

    fun clearLogs() {
        repository.diagnosticsLogger.clear()
    }

    fun exportLogs(): String {
        return repository.diagnosticsLogger.exportFormattedString()
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        repository.cleanup()
    }
}
