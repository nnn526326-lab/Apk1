# NexendFLY – perubahan kamera jaringan & kontrol penerbangan

## Yang diubah

- Menambahkan penemuan layanan kamera jaringan melalui Android NSD/mDNS untuk layanan standar `_rtsp._tcp`, `_http._tcp`, `_https._tcp`, dan `_mjpeg._tcp`.
- Menampilkan hingga tiga layanan kamera yang ditemukan (nama layanan, alamat IP, port, dan skema) pada layar FPV. Penemuan berjalan otomatis saat repository aplikasi dibuat.
- Mengaktifkan multicast lock selama proses discovery agar paket multicast DNS dapat diterima di Wi-Fi.
- Menghubungkan tombol ARM/TAKE-OFF, RTH, dan LAND ke jalur perintah repository. USB OTG ROTG/NexendUsbManager tidak diubah.
- ARM hanya dikirim ketika remote dan FC terhubung dan status FC DISARMED. RTH hanya ketika keduanya terhubung dan drone ARMED. LAND memakai perintah konfigurasi failsafe yang telah didokumentasikan di source (`SET_FAILSAFE`, argumen `0` = pendaratan terkendali), bukan MOTOR_STOP atau DISARM.
- Menambahkan dialog konfirmasi RTH dan LAND. Warna batas tombol ARM/LAND dianimasikan mengikuti status armed.

## Batas kompatibilitas kamera

Penemuan otomatis ini menemukan kamera/IP video receiver yang mengiklankan layanan standar melalui mDNS/NSD. Tidak semua kamera IP mengiklankan layanan tersebut. Banyak kamera memakai URL/path RTSP/HTTP proprietary, autentikasi, atau protokol vendor; discovery tidak menebak URL/path tersebut dan tidak menjamin video tampil. Modul video lama dan jalur USB UVC ROTG tetap dipertahankan. Deteksi layanan jaringan bukan bukti bahwa stream sudah berhasil didekode.

## Catatan kontrol penerbangan

ID `0x01` (ARM), `0x02` (DISARM), dan `0x03` (RTH) ditambahkan berdasarkan komentar protokol Nexend yang menyatakan ID 0x01–0x03 dipesan untuk remote ARM/DISARM/RTH. Perintah ARM/RTH membutuhkan firmware remote/FC yang benar-benar mendukung forwarding dan ACK untuk ID tersebut. LAND menggunakan definisi `SET_FAILSAFE` yang sudah ada. Jika firmware tidak mendukung, aplikasi akan menampilkan timeout/penolakan; jangan menganggap command berhasil hanya karena tombol ditekan.

Tombol utama saat drone ARMED adalah LAND terkendali; tidak ada aksi motor cut-off dari tombol tersebut. Jangan melakukan uji ARM, RTH, atau LAND dengan baling-baling terpasang di area orang. Uji pertama harus dilakukan di area aman, dengan propeller dilepas untuk validasi komunikasi jika prosedur firmware memungkinkan.

## Izin Android

Ditambahkan `ACCESS_WIFI_STATE` dan `CHANGE_WIFI_MULTICAST_STATE` untuk discovery multicast. INTERNET dan ACCESS_NETWORK_STATE yang sudah ada tetap dipertahankan.

## Checklist pengujian manual

1. Build Debug dan Release dari Android Studio/Gradle; pastikan konfigurasi signing release milik pengguna tetap tersedia.
2. Mode simulasi: pastikan layar live view dan status ARM virtual masih bekerja.
3. USB ROTG: colok/cabut perangkat, beri izin USB, pastikan kamera/telemetri USB lama tidak berubah.
4. Wi-Fi: hubungkan ponsel dan kamera yang mengiklankan RTSP/HTTP melalui mDNS ke jaringan yang sama; pastikan nama/IP/port tampil di panel kamera jaringan.
5. Kamera tanpa mDNS: pastikan aplikasi tidak mengklaim kamera terdeteksi; discovery ini memang tidak melakukan pemindaian seluruh subnet.
6. Hardware: dengan remote dan FC tersambung, uji ARM hanya di kondisi aman. Pastikan ACK/timeout ditampilkan.
7. Uji RTH hanya dengan GPS fix/home point valid dan ketinggian RTH aman. Pastikan status FC berubah ke mode RTH setelah FC mengonfirmasi.
8. Uji LAND saat kondisi aman; pastikan firmware mengeksekusi pendaratan terkendali. Jangan gunakan MOTOR_STOP/DISARM sebagai pengganti LAND di udara.
9. Cabut USB dan putus Wi-Fi; pastikan aplikasi tidak menampilkan kamera jaringan yang sudah hilang setelah event NSD service-lost.

## Status validasi

Source sudah diperbarui dan diperiksa secara statis. Build APK dan pengujian perangkat belum dijalankan dalam lingkungan ini karena Gradle/Gradle Wrapper tidak tersedia di workspace. Silakan build dan jalankan checklist di atas dari Android Studio; jika muncul error build atau log pengujian, kirimkan log-nya untuk perbaikan lanjutan.
